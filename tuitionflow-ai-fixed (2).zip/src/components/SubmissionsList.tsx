import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertCircle,
  Clock,
  MessageSquare,
  User,
  Calendar,
  Image as ImageIcon,
  ThumbsUp,
  RotateCcw,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Submission, Homework, Student, Language, Translations } from '../types';
import { subjectTranslations } from '../locales/translations';
import { playGentleChime } from '../utils/audioReminder';

interface Props {
  submissions: Submission[];
  homeworks: Homework[];
  students: Student[];
  lang: Language;
  t: Translations;
  onUpdateStatus: (submissionId: string, status: 'approved' | 'needs_correction', feedback: string) => Promise<void>;
  filterHomeworkId?: string | null;
  onClearFilterHomework?: () => void;
}

export const SubmissionsList: React.FC<Props> = ({
  submissions,
  homeworks,
  students,
  lang,
  t,
  onUpdateStatus,
  filterHomeworkId,
  onClearFilterHomework,
}) => {
  const [statusFilter, setStatusFilter] = useState<'all' | 'submitted' | 'needs_correction' | 'approved'>('all');
  const [selectedStudentFilter, setSelectedStudentFilter] = useState<string>('all');
  const [feedbackInputs, setFeedbackInputs] = useState<Record<string, string>>({});
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Filter submissions
  let filtered = submissions;
  if (filterHomeworkId) {
    filtered = filtered.filter((s) => s.homeworkId === filterHomeworkId);
  }
  if (statusFilter !== 'all') {
    filtered = filtered.filter((s) => s.status === statusFilter);
  }
  if (selectedStudentFilter !== 'all') {
    filtered = filtered.filter((s) => s.studentId === selectedStudentFilter);
  }

  // Sort: pending review first, then by date descending
  filtered.sort((a, b) => {
    if (a.status === 'submitted' && b.status !== 'submitted') return -1;
    if (b.status === 'submitted' && a.status !== 'submitted') return 1;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });

  const handleFeedbackChange = (submissionId: string, val: string) => {
    setFeedbackInputs((prev) => ({ ...prev, [submissionId]: val }));
  };

  const handleAction = async (sub: Submission, status: 'approved' | 'needs_correction') => {
    const feedback = feedbackInputs[sub.id] !== undefined ? feedbackInputs[sub.id] : (sub.teacherFeedback || '');
    setUpdatingId(sub.id);
    try {
      await onUpdateStatus(sub.id, status, feedback);
      if (status === 'approved') {
        playGentleChime('success');
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
        });
      }
    } finally {
      setUpdatingId(null);
    }
  };

  const selectedHomework = filterHomeworkId ? homeworks.find((h) => h.id === filterHomeworkId) : null;

  return (
    <div className="space-y-6">
      {/* Top Filter Bar */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
        {/* Status Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              statusFilter === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {lang === 'ta' ? 'அனைத்தும்' : 'All'} ({submissions.length})
          </button>
          <button
            onClick={() => setStatusFilter('submitted')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
              statusFilter === 'submitted'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{t.submittedStatus}</span>
            <span className="ml-1 px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
              {submissions.filter((s) => s.status === 'submitted').length}
            </span>
          </button>
          <button
            onClick={() => setStatusFilter('needs_correction')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
              statusFilter === 'needs_correction'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-rose-50 text-rose-800 border border-rose-200 hover:bg-rose-100'
            }`}
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{t.needsCorrectionStatus}</span>
          </button>
          <button
            onClick={() => setStatusFilter('approved')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
              statusFilter === 'approved'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{t.approvedStatus}</span>
          </button>
        </div>

        {/* Student filter dropdown */}
        <div className="flex items-center gap-2">
          <select
            value={selectedStudentFilter}
            onChange={(e) => setSelectedStudentFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white"
          >
            <option value="all">{lang === 'ta' ? 'அனைத்து மாணவர்கள்' : 'All Students'}</option>
            {students.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.studentCode})
              </option>
            ))}
          </select>

          {/* Active Homework filter tag */}
          {selectedHomework && (
            <div className="flex items-center gap-1.5 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-xl text-xs text-blue-700 font-bold">
              <span>{selectedHomework.title}</span>
              <button
                onClick={onClearFilterHomework}
                className="text-blue-500 hover:text-blue-800"
              >
                ✕
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Submissions List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200/80 p-8">
          <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center">
            <Clock className="w-7 h-7" />
          </div>
          <h3 className="font-bold text-slate-800 text-base">
            {lang === 'ta' ? 'சமர்ப்பிப்புகள் எதுவும் இல்லை' : 'No Submissions Found'}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {lang === 'ta'
              ? 'மாணவர்கள் தங்கள் போர்டலில் விடைகளை சமர்ப்பித்ததும் இங்கே காண்பிக்கப்படும்.'
              : 'When students submit their homework answers from their phones, they will appear here for grading.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5">
          {filtered.map((sub) => {
            const hw = homeworks.find((h) => h.id === sub.homeworkId);
            const stu = students.find((s) => s.id === sub.studentId);
            const subMeta = hw ? subjectTranslations[hw.subject] : null;

            const isApproved = sub.status === 'approved';
            const isCorrection = sub.status === 'needs_correction';
            const isSubmitted = sub.status === 'submitted';

            const currentFeedback = feedbackInputs[sub.id] !== undefined ? feedbackInputs[sub.id] : (sub.teacherFeedback || '');

            return (
              <div
                key={sub.id}
                className={`bg-white rounded-3xl border p-5 sm:p-6 transition-all shadow-sm ${
                  isSubmitted
                    ? 'border-amber-300 ring-2 ring-amber-100'
                    : isApproved
                    ? 'border-emerald-200'
                    : 'border-slate-200'
                }`}
              >
                {/* Header: Student info & Homework reference */}
                <div className="flex flex-wrap items-start justify-between gap-3 pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-linear-to-tr from-teal-500 to-blue-600 text-white font-extrabold text-base flex items-center justify-center shadow-xs">
                      {(sub.studentName || 'S').charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900 text-base">
                          {sub.studentName}
                        </h4>
                        {stu && (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-600">
                            {stu.grade} • {stu.studentCode}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
                        {subMeta && (
                          <span className="font-semibold text-slate-700">
                            {lang === 'ta' ? subMeta.ta : subMeta.en}:
                          </span>
                        )}
                        <span className="font-medium text-slate-800">{hw?.title || 'Homework'}</span>
                        {sub.submittedAt && (
                          <span className="text-slate-400 text-[11px]">
                            • {new Date(sub.submittedAt).toLocaleString()}
                          </span>
                        )}
                      </p>
                    </div>
                  </div>

                  {/* Status Tag */}
                  <div>
                    {isApproved && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{t.approvedStatus}</span>
                      </span>
                    )}
                    {isCorrection && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>{t.needsCorrectionStatus}</span>
                      </span>
                    )}
                    {isSubmitted && (
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{lang === 'ta' ? 'புதிய சமர்ப்பிப்பு — மதிப்பாய்வு செய்க' : 'Needs Review'}</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Homework Question reference for teacher convenience */}
                {hw && (
                  <div className="mt-3.5 p-3 rounded-2xl bg-slate-50/70 border border-slate-100 text-xs text-slate-600">
                    <span className="font-bold text-slate-700 block mb-0.5">
                      {lang === 'ta' ? 'கொடுக்கப்பட்ட வினா / வழிமுறை:' : 'Question / Instructions:'}
                    </span>
                    <p className="line-clamp-2">{hw.instructions}</p>
                  </div>
                )}

                {/* Student's Answer Text Box */}
                <div className="mt-4">
                  <span className="text-xs font-bold text-slate-700 block mb-1">
                    {lang === 'ta' ? 'மாணவரின் விடை:' : "Student's Written Answer:"}
                  </span>
                  <div className="p-4 rounded-2xl bg-blue-50/40 border border-blue-100 text-sm font-medium text-slate-900 whitespace-pre-wrap leading-relaxed">
                    {sub.answer || (lang === 'ta' ? '(விடை தட்டச்சு செய்யப்படவில்லை)' : '(No text answer entered)')}
                  </div>
                </div>

                {/* Student's Uploaded Homework Photo */}
                {sub.attachmentUrl && (
                  <div className="mt-4">
                    <span className="text-xs font-bold text-slate-700 block mb-1">
                      {lang === 'ta' ? 'மாணவர் பதிவேற்றிய நோட்டுப் புத்தக புகைப்படம்:' : "Student's Uploaded Photo / Work:"}
                    </span>
                    <button
                      type="button"
                      onClick={() => setPreviewImage(sub.attachmentUrl || null)}
                      className="group/img relative inline-block rounded-2xl overflow-hidden border border-slate-200 shadow-xs hover:border-blue-400 transition"
                    >
                      <img
                        src={sub.attachmentUrl}
                        alt="Student work submission"
                        className="max-h-56 max-w-xs object-cover rounded-2xl"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/img:opacity-100 flex items-center justify-center text-white text-xs font-bold transition">
                        <ExternalLink className="w-4 h-4 mr-1" />
                        {lang === 'ta' ? 'பெரிதாக்குக' : 'Zoom Image'}
                      </div>
                    </button>
                  </div>
                )}

                {/* Teacher Feedback & Action Area */}
                <div className="mt-5 pt-4 border-t border-slate-100 space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                      <span>{t.teacherFeedbackLabel}</span>
                    </label>
                    <textarea
                      rows={2}
                      value={currentFeedback}
                      onChange={(e) => handleFeedbackChange(sub.id, e.target.value)}
                      placeholder={
                        isApproved
                          ? (lang === 'ta' ? 'மிகச் சிறப்பு! பாராட்டுக்கள்!' : 'Excellent work! Keep it up!')
                          : t.feedbackPlaceholder
                      }
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-xs sm:text-sm text-slate-800 outline-hidden transition"
                    />
                  </div>

                  {/* Approve / Request Correction Buttons */}
                  <div className="flex flex-wrap items-center justify-end gap-2.5">
                    <button
                      type="button"
                      disabled={updatingId === sub.id}
                      onClick={() => handleAction(sub, 'needs_correction')}
                      className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold border transition ${
                        isCorrection
                          ? 'bg-rose-100 text-rose-800 border-rose-300'
                          : 'bg-white text-rose-700 border-rose-200 hover:bg-rose-50'
                      }`}
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>{t.requestCorrectionBtn}</span>
                    </button>

                    <button
                      type="button"
                      disabled={updatingId === sub.id}
                      onClick={() => handleAction(sub, 'approved')}
                      className={`flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-bold text-white shadow-md active:scale-95 transition ${
                        isApproved
                          ? 'bg-emerald-700'
                          : 'bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700'
                      }`}
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                      <span>{isApproved ? t.approvedStatus : t.approveBtn}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Image zoom modal */}
      {previewImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-4 shadow-2xl overflow-hidden relative">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-bold text-slate-900 text-sm">
                {lang === 'ta' ? 'மாணவரின் விடைத்தாள் படம்' : "Student's Uploaded Homework Image"}
              </h4>
              <button
                onClick={() => setPreviewImage(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>
            <img
              src={previewImage}
              alt="Zoomed submission"
              className="max-h-[80vh] w-full object-contain rounded-2xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
