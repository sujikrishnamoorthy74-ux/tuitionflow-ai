import React, { useState, useEffect } from 'react';
import {
  X,
  BookPlus,
  Send,
  Calendar,
  Image as ImageIcon,
  CheckSquare,
  Square,
  Users,
  Sparkles,
  AlertCircle,
  Trash2,
} from 'lucide-react';
import { Homework, Student, Subject, Language, Translations } from '../types';
import { subjectTranslations } from '../locales/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (homework: Homework) => Promise<void>;
  editingHomework: Homework | null;
  students: Student[];
  lang: Language;
  t: Translations;
}

export const CreateHomeworkModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSave,
  editingHomework,
  students,
  lang,
  t,
}) => {
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState<Subject>('Tamil');
  const [instructions, setInstructions] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [assignedStudentIds, setAssignedStudentIds] = useState<string[]>([]);
  const [attachmentUrl, setAttachmentUrl] = useState<string | undefined>(undefined);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const subjectsList: Subject[] = ['Tamil', 'English', 'Maths', 'Science', 'Social Science'];

  useEffect(() => {
    if (editingHomework) {
      setTitle(editingHomework.title);
      setSubject(editingHomework.subject);
      setInstructions(editingHomework.instructions);
      setDueDate(editingHomework.dueDate);
      setAssignedStudentIds(editingHomework.assignedStudentIds);
      setAttachmentUrl(editingHomework.attachmentUrl);
    } else {
      setTitle('');
      setSubject('Tamil');
      setInstructions('');
      // Default due date to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setDueDate(tomorrow.toISOString().split('T')[0]);
      // Default assign all students
      setAssignedStudentIds(students.map((s) => s.id));
      setAttachmentUrl(undefined);
    }
    setError('');
  }, [editingHomework, students, isOpen]);

  if (!isOpen) return null;

  const toggleStudent = (id: string) => {
    if (assignedStudentIds.includes(id)) {
      setAssignedStudentIds(assignedStudentIds.filter((sid) => sid !== id));
    } else {
      setAssignedStudentIds([...assignedStudentIds, id]);
    }
  };

  const handleSelectAll = () => {
    setAssignedStudentIds(students.map((s) => s.id));
  };

  const handleDeselectAll = () => {
    setAssignedStudentIds([]);
  };

  const handleSelectClass = (gradeName: string) => {
    const classStudentIds = students.filter((s) => s.grade === gradeName).map((s) => s.id);
    const set = new Set([...assignedStudentIds, ...classStudentIds]);
    setAssignedStudentIds(Array.from(set));
  };

  // Quick Due Date buttons
  const setQuickDate = (daysAhead: number) => {
    const d = new Date();
    d.setDate(d.getDate() + daysAhead);
    setDueDate(d.toISOString().split('T')[0]);
  };

  // Handle Image Upload with file reader
  const handleImageFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      setError(
        lang === 'ta'
          ? 'படத்தின் அளவு 2MB-க்கு குறைவாக இருக்க வேண்டும்.'
          : 'Image size should be less than 2MB.'
      );
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setAttachmentUrl(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError(lang === 'ta' ? 'வீட்டுப்பாடத்தின் தலைப்பை உள்ளிடவும்' : 'Please enter homework title');
      return;
    }
    if (!instructions.trim()) {
      setError(lang === 'ta' ? 'வழிமுறைகளை உள்ளிடவும்' : 'Please enter instructions');
      return;
    }
    if (!dueDate) {
      setError(lang === 'ta' ? 'கடைசி நாளை தேர்வு செய்யவும்' : 'Please choose due date');
      return;
    }
    if (assignedStudentIds.length === 0) {
      setError(
        lang === 'ta'
          ? 'குறைந்தது ஒரு மாணவரையாவது தேர்ந்தெடுக்கவும்'
          : 'Please select at least one student'
      );
      return;
    }

    setSaving(true);
    try {
      const hwToSave: Homework = {
        id: editingHomework ? editingHomework.id : `hw-${Date.now()}`,
        title: title.trim(),
        subject,
        instructions: instructions.trim(),
        dueDate,
        assignedStudentIds,
        createdAt: editingHomework ? editingHomework.createdAt : new Date().toISOString(),
      };
      if (attachmentUrl) {
        hwToSave.attachmentUrl = attachmentUrl;
      }

      await onSave(hwToSave);
      onClose();
    } catch (err) {
      setError(String(err));
    } finally {
      setSaving(false);
    }
  };

  // Extract unique classes
  const uniqueClasses = Array.from(new Set(students.map((s) => s.grade))).sort();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-linear-to-r from-blue-600 via-indigo-600 to-teal-500 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-xs">
              <BookPlus className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg">
                {editingHomework ? t.editHomework : t.createHomework}
              </h3>
              <p className="text-xs text-blue-100">
                {lang === 'ta'
                  ? 'மாணவர்களுக்கு பாடம் & வினாக்களை ஒதுக்கீடு செய்க'
                  : 'Assign homework with instructions & due date'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white/80 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Subject Selector Pills */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              {t.subject} <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {subjectsList.map((sub) => {
                const subMeta = subjectTranslations[sub];
                const isSelected = subject === sub;
                return (
                  <button
                    key={sub}
                    type="button"
                    onClick={() => setSubject(sub)}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition text-left ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-2 ring-blue-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white text-slate-700'
                    }`}
                  >
                    <span className={`w-3 h-3 rounded-full ${subMeta.iconBg}`} />
                    <span className="truncate">
                      {lang === 'ta' ? subMeta.ta : subMeta.en}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.homeworkTitle} <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                lang === 'ta'
                  ? 'எ.கா. திருக்குறள் மனப்பாடப் பகுதி அல்லது Chapter 3 Equations'
                  : 'e.g. Chapter 4 Fractions Practice Set'
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-sm font-semibold text-slate-800 outline-hidden transition"
              required
            />
          </div>

          {/* Instructions */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-700">
                {t.instructions} <span className="text-rose-500">*</span>
              </label>
              <span className="text-[11px] text-slate-500">
                {lang === 'ta' ? 'தமிழ் & ஆங்கிலத்தில் தட்டச்சு செய்யலாம்' : 'Supports Tamil & English'}
              </span>
            </div>
            <textarea
              rows={4}
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder={
                lang === 'ta'
                  ? 'மாணவர்கள் செய்ய வேண்டிய வினாக்கள், பக்க எண்கள் அல்லது குறிப்புகள்...'
                  : 'Write questions, chapter numbers, or detailed instructions for students...'
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-sm text-slate-800 outline-hidden transition"
              required
            />
          </div>

          {/* Due Date & Quick Pickers */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.dueDate} <span className="text-rose-500">*</span>
            </label>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative flex-1 min-w-[200px]">
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-sm font-medium text-slate-800 outline-hidden transition"
                  required
                />
                <Calendar className="w-4 h-4 text-slate-400 absolute right-3.5 top-3 pointer-events-none" />
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setQuickDate(1)}
                  className="px-2.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                >
                  {lang === 'ta' ? 'நாளை' : 'Tomorrow'}
                </button>
                <button
                  type="button"
                  onClick={() => setQuickDate(3)}
                  className="px-2.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                >
                  +3 {lang === 'ta' ? 'நாட்கள்' : 'Days'}
                </button>
                <button
                  type="button"
                  onClick={() => setQuickDate(7)}
                  className="px-2.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
                >
                  +1 {lang === 'ta' ? 'வாரம்' : 'Week'}
                </button>
              </div>
            </div>
          </div>

          {/* Optional Attachment Image / Worksheet */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.optionalAttachment}
            </label>
            {attachmentUrl ? (
              <div className="relative inline-block border border-slate-200 rounded-2xl overflow-hidden p-1 bg-slate-50">
                <img
                  src={attachmentUrl}
                  alt="Attachment preview"
                  className="max-h-40 rounded-xl object-contain"
                />
                <button
                  type="button"
                  onClick={() => setAttachmentUrl(undefined)}
                  className="absolute top-2 right-2 p-1.5 rounded-full bg-rose-600 text-white shadow-md hover:bg-rose-700 transition"
                  title="Remove image"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-2xl cursor-pointer bg-slate-50/50 hover:bg-blue-50/20 transition">
                <ImageIcon className="w-6 h-6 text-slate-400 mb-1" />
                <span className="text-xs font-semibold text-slate-600">
                  {t.uploadWorksheetImage}
                </span>
                <span className="text-[10px] text-slate-400 mt-0.5">PNG, JPG up to 2MB</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageFile}
                  className="hidden"
                />
              </label>
            )}
          </div>

          {/* Assign to Students */}
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-blue-600" />
                <span>
                  {t.assignToStudents} ({assignedStudentIds.length}/{students.length})
                </span>
                <span className="text-rose-500">*</span>
              </label>

              <div className="flex items-center gap-1.5 text-xs">
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="text-blue-600 hover:underline font-semibold"
                >
                  {t.selectAll}
                </button>
                <span className="text-slate-300">|</span>
                <button
                  type="button"
                  onClick={handleDeselectAll}
                  className="text-slate-500 hover:underline font-medium"
                >
                  {t.deselectAll}
                </button>
              </div>
            </div>

            {/* Quick Class filters */}
            {uniqueClasses.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 mb-2.5">
                <span className="text-[10px] font-bold text-slate-400 uppercase">
                  {lang === 'ta' ? 'வகுப்பு:' : 'Class:'}
                </span>
                {uniqueClasses.map((cls) => (
                  <button
                    key={cls}
                    type="button"
                    onClick={() => handleSelectClass(cls)}
                    className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 border border-slate-200 transition"
                  >
                    + {cls}
                  </button>
                ))}
              </div>
            )}

            {/* Student selection grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto p-1 border border-slate-200 rounded-2xl bg-slate-50/50">
              {students.map((student) => {
                const isSelected = assignedStudentIds.includes(student.id);
                return (
                  <button
                    key={student.id}
                    type="button"
                    onClick={() => toggleStudent(student.id)}
                    className={`flex items-center gap-2.5 p-2 rounded-xl text-left transition ${
                      isSelected
                        ? 'bg-blue-100/70 border border-blue-300 text-blue-900'
                        : 'bg-white border border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    {isSelected ? (
                      <CheckSquare className="w-4 h-4 text-blue-600 shrink-0" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-400 shrink-0" />
                    )}
                    <div className="min-w-0">
                      <p className="text-xs font-bold truncate">{student.name}</p>
                      <p className="text-[10px] text-slate-500 truncate">
                        {student.grade} • {student.studentCode}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold bg-linear-to-r from-blue-600 via-indigo-600 to-teal-600 text-white shadow-md hover:opacity-95 active:scale-95 disabled:opacity-50 transition"
            >
              <Send className="w-4 h-4" />
              <span>{saving ? 'Assigning...' : t.assignHomeworkBtn}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
