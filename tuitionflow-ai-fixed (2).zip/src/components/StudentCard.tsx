import React, { useState } from 'react';
import {
  User,
  GraduationCap,
  Phone,
  Key,
  Copy,
  Check,
  Edit2,
  Trash2,
  MessageCircle,
  ExternalLink,
  BookCheck,
  Clock,
} from 'lucide-react';
import { Student, Homework, Submission, Language, Translations } from '../types';

interface Props {
  student: Student;
  homeworks: Homework[];
  submissions: Submission[];
  lang: Language;
  t: Translations;
  onEdit: (student: Student) => void;
  onDelete: (studentId: string) => void;
  onOpenAsStudent: (student: Student) => void;
}

export const StudentCard: React.FC<Props> = ({
  student,
  homeworks,
  submissions,
  lang,
  t,
  onEdit,
  onDelete,
  onOpenAsStudent,
}) => {
  const [copied, setCopied] = useState(false);

  // Homework assigned to this student
  const assigned = homeworks.filter((h) => h.assignedStudentIds.includes(student.id));
  const studentSubmissions = submissions.filter((s) => s.studentId === student.id);

  const completedCount = studentSubmissions.filter(
    (s) => s.status === 'approved' || s.status === 'submitted'
  ).length;
  const pendingCount = Math.max(0, assigned.length - completedCount);

  // Direct student link
  const directLink = `${typeof window !== 'undefined' ? window.location.origin : ''}/?student=${encodeURIComponent(
    student.studentCode
  )}`;

  const handleCopyLink = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(directLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  // WhatsApp share link for parent
  const cleanPhone = student.parentPhone ? student.parentPhone.replace(/[^0-9]/g, '') : '';
  const waMessage = encodeURIComponent(
    lang === 'ta'
      ? `வணக்கம்! ${student.name} மாணவருக்கான டியூஷன் வீட்டுப்பாடம் போர்டல் இணைப்பு: ${directLink}`
      : `Hello! Tuition homework portal access link for ${student.name}: ${directLink}`
  );
  const waUrl = cleanPhone ? `https://wa.me/${cleanPhone}?text=${waMessage}` : null;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-all p-5 flex flex-col justify-between group relative overflow-hidden">
      {/* Top colorful gradient accent line */}
      <div className="absolute top-0 left-0 right-0 h-1.5 bg-linear-to-r from-blue-500 via-indigo-500 to-teal-400" />

      <div>
        {/* Header with Avatar & Details */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-linear-to-br from-blue-600 to-indigo-600 text-white font-black text-lg flex items-center justify-center shadow-sm">
              {student.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base group-hover:text-blue-600 transition truncate max-w-[180px]">
                {student.name}
              </h3>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                  <GraduationCap className="w-3 h-3 mr-1" />
                  {student.grade}
                </span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-mono font-bold bg-slate-100 text-slate-700">
                  <Key className="w-3 h-3 mr-1 text-slate-400" />
                  {student.studentCode}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Edit/Delete buttons */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => onEdit(student)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition"
              title={t.editStudent}
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(student.id)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
              title={t.deleteStudent}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Contact info */}
        {student.parentPhone && (
          <div className="mt-3.5 flex items-center justify-between text-xs text-slate-600 bg-slate-50/70 p-2 rounded-xl">
            <span className="flex items-center gap-1.5 truncate">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span>{student.parentPhone}</span>
            </span>
            {waUrl && (
              <a
                href={waUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200"
              >
                <MessageCircle className="w-3 h-3" />
                <span>WhatsApp</span>
              </a>
            )}
          </div>
        )}

        {/* Homework Stats Pill */}
        <div className="grid grid-cols-2 gap-2 mt-4">
          <div className="bg-amber-50/80 border border-amber-200/70 rounded-xl p-2.5">
            <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-700">
              <Clock className="w-3.5 h-3.5" />
              <span>{lang === 'ta' ? 'நிலுவை' : 'Pending'}</span>
            </div>
            <div className="text-xl font-black text-amber-800 mt-0.5">
              {pendingCount}
            </div>
          </div>
          <div className="bg-emerald-50/80 border border-emerald-200/70 rounded-xl p-2.5">
            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
              <BookCheck className="w-3.5 h-3.5" />
              <span>{lang === 'ta' ? 'முடித்தவை' : 'Completed'}</span>
            </div>
            <div className="text-xl font-black text-emerald-800 mt-0.5">
              {completedCount} / {assigned.length}
            </div>
          </div>
        </div>
      </div>

      {/* Action Footer: Copy Link & Quick Open Portal */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
        <button
          onClick={handleCopyLink}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold transition ${
            copied
              ? 'bg-emerald-600 text-white'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
          title={t.copyStudentLink}
        >
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? t.linkCopied : t.copyStudentLink}</span>
        </button>

        <button
          onClick={() => onOpenAsStudent(student)}
          className="flex items-center justify-center gap-1 py-2 px-2.5 rounded-xl text-xs font-bold bg-teal-50 text-teal-700 hover:bg-teal-100 border border-teal-200 transition"
          title="Open Portal as this Student"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{lang === 'ta' ? 'திறக்க' : 'Open'}</span>
        </button>
      </div>
    </div>
  );
};
