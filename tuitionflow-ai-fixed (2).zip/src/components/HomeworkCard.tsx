import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  Printer,
  Edit2,
  Trash2,
  Users,
  CheckCircle2,
  AlertTriangle,
  ImageIcon,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Homework, Student, Submission, Language, Translations } from '../types';
import { subjectTranslations } from '../locales/translations';

interface Props {
  homework: Homework;
  students: Student[];
  submissions: Submission[];
  lang: Language;
  t: Translations;
  onEdit: (homework: Homework) => void;
  onDelete: (homeworkId: string) => void;
  onPrint: (homework: Homework) => void;
  onViewSubmissions?: (homeworkId: string) => void;
}

export const HomeworkCard: React.FC<Props> = ({
  homework,
  students,
  submissions,
  lang,
  t,
  onEdit,
  onDelete,
  onPrint,
  onViewSubmissions,
}) => {
  const [expanded, setExpanded] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);

  const subMeta = subjectTranslations[homework.subject] || subjectTranslations.Tamil;

  // Submissions for this homework
  const hwSubmissions = submissions.filter((s) => s.homeworkId === homework.id);
  const approvedCount = hwSubmissions.filter((s) => s.status === 'approved').length;
  const submittedCount = hwSubmissions.filter((s) => s.status === 'submitted').length;
  const totalAssigned = homework.assignedStudentIds.length;
  const completedRate = totalAssigned > 0 ? Math.round(((approvedCount + submittedCount) / totalAssigned) * 100) : 0;

  // Due date calculation
  const today = new Date().toISOString().split('T')[0];
  const isOverdue = homework.dueDate < today;
  const isDueToday = homework.dueDate === today;

  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-md transition-all p-5 flex flex-col justify-between relative overflow-hidden group">
      {/* Top subtle subject color accent */}
      <div className={`absolute top-0 left-0 right-0 h-1.5 ${subMeta.iconBg}`} />

      <div>
        {/* Top line: Subject badge & Due date */}
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <span
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${subMeta.color}`}
          >
            <span className={`w-2 h-2 rounded-full ${subMeta.iconBg}`} />
            <span>{lang === 'ta' ? subMeta.ta : subMeta.en}</span>
          </span>

          {/* Due date badge */}
          <div className="flex items-center gap-1.5">
            {isOverdue ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-700 border border-rose-200 animate-pulse">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{t.overdue}</span>
              </span>
            ) : isDueToday ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
                <Clock className="w-3.5 h-3.5" />
                <span>{t.dueSoon}</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-500">
                <Calendar className="w-3.5 h-3.5" />
                <span>{homework.dueDate}</span>
              </span>
            )}
          </div>
        </div>

        {/* Title */}
        <h3 className="font-extrabold text-slate-900 text-base sm:text-lg mb-2 leading-snug group-hover:text-blue-600 transition">
          {homework.title}
        </h3>

        {/* Instructions */}
        <div className="text-xs sm:text-sm text-slate-600 bg-slate-50/80 rounded-2xl p-3 border border-slate-100 whitespace-pre-line relative">
          <p className={expanded ? '' : 'line-clamp-3'}>{homework.instructions}</p>
          {homework.instructions.length > 120 && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="mt-2 text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              <span>{expanded ? (lang === 'ta' ? 'குறைக்க' : 'Show Less') : (lang === 'ta' ? 'மேலும் வாசிக்க' : 'Read Full Instructions')}</span>
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>

        {/* Attachment preview if present */}
        {homework.attachmentUrl && (
          <div className="mt-3">
            <button
              type="button"
              onClick={() => setShowImageModal(true)}
              className="flex items-center gap-2 p-2 rounded-xl bg-blue-50/70 border border-blue-200 text-xs font-bold text-blue-700 hover:bg-blue-100 transition"
            >
              <ImageIcon className="w-4 h-4 text-blue-600" />
              <span>{lang === 'ta' ? 'இணைக்கப்பட்ட பணித்தாள் படம்' : 'Worksheet Reference Image'}</span>
              <span className="text-[10px] bg-blue-200/80 px-1.5 py-0.5 rounded-md">View</span>
            </button>
          </div>
        )}

        {/* Completion Progress Bar */}
        <div className="mt-4 pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="text-slate-500 flex items-center gap-1 font-medium">
              <Users className="w-3.5 h-3.5 text-slate-400" />
              <span>
                {approvedCount + submittedCount} / {totalAssigned} {lang === 'ta' ? 'மாணவர்கள்' : 'Students'}
              </span>
            </span>
            <span className="font-bold text-slate-700">{completedRate}%</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-linear-to-r from-blue-500 to-teal-500 h-full rounded-full transition-all duration-500"
              style={{ width: `${completedRate}%` }}
            />
          </div>
        </div>
      </div>

      {/* Footer Controls: Print, Edit, Delete, View Submissions */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
        <button
          onClick={() => onPrint(homework)}
          className="flex items-center gap-1.5 py-2 px-3 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition"
          title={t.printWorksheet}
        >
          <Printer className="w-3.5 h-3.5 text-slate-600" />
          <span className="hidden sm:inline">{lang === 'ta' ? 'அச்சிடுக' : 'Print Sheet'}</span>
        </button>

        <div className="flex items-center gap-1.5">
          {onViewSubmissions && (
            <button
              onClick={() => onViewSubmissions(homework.id)}
              className="px-3 py-2 rounded-xl text-xs font-bold bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200 transition"
            >
              {lang === 'ta' ? 'சமர்ப்பிப்புகள்' : 'Submissions'} ({hwSubmissions.length})
            </button>
          )}

          <button
            onClick={() => onEdit(homework)}
            className="p-2 rounded-xl text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition"
            title={t.editHomework}
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(homework.id)}
            className="p-2 rounded-xl text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition"
            title={t.deleteHomework}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Image zoom modal */}
      {showImageModal && homework.attachmentUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-4 shadow-2xl overflow-hidden relative">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-bold text-slate-900 text-sm">{homework.title}</h4>
              <button
                onClick={() => setShowImageModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                ✕
              </button>
            </div>
            <img
              src={homework.attachmentUrl}
              alt={homework.title}
              className="max-h-[75vh] w-full object-contain rounded-2xl"
            />
          </div>
        </div>
      )}
    </div>
  );
};
