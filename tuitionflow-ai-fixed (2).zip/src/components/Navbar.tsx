import React from 'react';
import {
  GraduationCap,
  Sparkles,
  BookOpen,
  UserCheck,
  Globe,
  HelpCircle,
  Volume2,
  VolumeX,
  LogOut,
  Wifi,
} from 'lucide-react';
import { Language, Student } from '../types';
import { PWAInstallButton } from './PWAInstallButton';
import { playGentleChime } from '../utils/audioReminder';

interface Props {
  lang: Language;
  onToggleLang: () => void;
  activeRole: 'teacher' | 'student';
  onSwitchRole: (role: 'teacher' | 'student') => void;
  currentStudent: Student | null;
  onStudentLogout: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onOpenSetupGuide: () => void;
}

export const Navbar: React.FC<Props> = ({
  lang,
  onToggleLang,
  activeRole,
  onSwitchRole,
  currentStudent,
  onStudentLogout,
  soundEnabled,
  onToggleSound,
  onOpenSetupGuide,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-2">
          {/* Brand Logo & Title */}
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex items-center justify-center w-10 h-10 rounded-2xl bg-linear-to-tr from-blue-600 via-indigo-600 to-teal-500 text-white shadow-md shadow-blue-500/20 shrink-0">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base sm:text-lg tracking-tight bg-linear-to-r from-blue-700 via-indigo-700 to-teal-600 bg-clip-text text-transparent truncate">
                  TuitionFlow AI
                </span>
                <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                  <Sparkles className="w-2.5 h-2.5 mr-0.5" />
                  Live Sync
                </span>
              </div>
              <p className="text-[11px] text-slate-500 truncate hidden xs:block">
                {lang === 'ta' ? 'ஸ்மார்ட் வீட்டுப்பாடம் போர்டல்' : 'Smart Tuition Homework Portal'}
              </p>
            </div>
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200/70 shadow-inner">
            <button
              onClick={() => onSwitchRole('teacher')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeRole === 'teacher'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600" />
              <span>{lang === 'ta' ? 'ஆசிரியர்' : 'Teacher'}</span>
            </button>
            <button
              onClick={() => onSwitchRole('student')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeRole === 'student'
                  ? 'bg-white text-teal-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-teal-600" />
              <span>{lang === 'ta' ? 'மாணவர்' : 'Student'}</span>
            </button>
          </div>

          {/* Utility Controls & Student Status */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Logged in student badge */}
            {activeRole === 'student' && currentStudent && (
              <div className="hidden md:flex items-center gap-1.5 bg-teal-50 border border-teal-200 px-2.5 py-1 rounded-xl text-xs font-medium text-teal-800">
                <span className="w-2 h-2 rounded-full bg-teal-500 animate-pulse"></span>
                <span className="font-bold truncate max-w-[120px]">{currentStudent.name}</span>
                <button
                  onClick={onStudentLogout}
                  title="Switch or Exit student"
                  className="ml-1 text-slate-400 hover:text-rose-600 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Language Toggle */}
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 transition"
              title="Toggle Tamil / English"
            >
              <Globe className="w-3.5 h-3.5 text-indigo-600" />
              <span>{lang === 'en' ? 'தமிழ்' : 'English'}</span>
            </button>

            {/* Chime Sound Toggle */}
            <button
              onClick={() => {
                onToggleSound();
                if (!soundEnabled) {
                  playGentleChime('reminder');
                }
              }}
              className={`p-2 rounded-xl text-xs border transition ${
                soundEnabled
                  ? 'border-indigo-200 bg-indigo-50 text-indigo-700'
                  : 'border-slate-200 bg-white text-slate-400 hover:text-slate-600'
              }`}
              title={soundEnabled ? 'Chime sound is ON' : 'Chime sound is OFF'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Setup / Help Button */}
            <button
              onClick={onOpenSetupGuide}
              className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border border-blue-200 bg-blue-50/70 hover:bg-blue-100 text-blue-700 transition"
              title="Setup and Live Sharing Guide"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{lang === 'ta' ? 'உதவி' : 'Guide'}</span>
            </button>

            {/* PWA Install */}
            <PWAInstallButton lang={lang} />
          </div>
        </div>
      </div>
    </header>
  );
};
