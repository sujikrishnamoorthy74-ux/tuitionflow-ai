import React from 'react';
import { Printer, X, GraduationCap } from 'lucide-react';
import { Homework, Language } from '../types';
import { subjectTranslations } from '../locales/translations';

interface Props {
  homework: Homework;
  lang: Language;
  onClose: () => void;
}

export const PrintableWorksheet: React.FC<Props> = ({ homework, lang, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const subMeta = subjectTranslations[homework.subject] || subjectTranslations.Tamil;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl border border-slate-100 overflow-hidden my-6 flex flex-col">
        {/* Screen Controls (Hidden in Print) */}
        <div className="print:hidden bg-slate-900 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-teal-400" />
            <span className="font-bold text-sm">
              {lang === 'ta' ? 'அச்சிடும் மாதிரிப் பார்வை (Print Preview)' : 'Worksheet Print Preview'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-600 text-white font-bold text-xs shadow-md transition"
            >
              <Printer className="w-4 h-4" />
              <span>{lang === 'ta' ? 'அச்சிடுக' : 'Print Worksheet'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Paper Content */}
        <div className="p-8 sm:p-12 text-slate-900 bg-white font-sans print:p-0 print:m-0 max-h-[85vh] overflow-y-auto print:max-h-none print:overflow-visible">
          {/* Header */}
          <div className="border-b-2 border-slate-800 pb-4 mb-6 text-center relative">
            <div className="flex items-center justify-center gap-2 mb-1">
              <GraduationCap className="w-6 h-6 text-slate-800" />
              <h1 className="text-2xl font-black tracking-tight uppercase">
                TUITIONFLOW SMART HOMEWORK
              </h1>
            </div>
            <p className="text-xs font-semibold text-slate-600 uppercase tracking-widest">
              Daily Tuition Assignment & Practice Worksheet
            </p>
          </div>

          {/* Student & Assignment Meta Fields */}
          <div className="grid grid-cols-2 gap-4 border border-slate-300 rounded-xl p-4 mb-6 text-xs sm:text-sm">
            <div>
              <span className="font-bold text-slate-700">Student Name: </span>
              <span className="border-b border-dotted border-slate-400 inline-block w-48"></span>
            </div>
            <div>
              <span className="font-bold text-slate-700">Student Code / Roll: </span>
              <span className="border-b border-dotted border-slate-400 inline-block w-36"></span>
            </div>
            <div>
              <span className="font-bold text-slate-700">Subject: </span>
              <span className="font-semibold text-slate-900">
                {subMeta.en} ({subMeta.ta})
              </span>
            </div>
            <div>
              <span className="font-bold text-slate-700">Submission Due Date: </span>
              <span className="font-semibold text-slate-900">{homework.dueDate}</span>
            </div>
          </div>

          {/* Assignment Title & Questions */}
          <div className="mb-6">
            <div className="bg-slate-100 p-3 rounded-lg border border-slate-200 mb-4">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                Assignment Title
              </span>
              <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                {homework.title}
              </h2>
            </div>

            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Instructions & Questions:
              </span>
              <p className="text-sm text-slate-800 whitespace-pre-line leading-relaxed">
                {homework.instructions}
              </p>
            </div>
          </div>

          {/* If there is an image worksheet attached, render it */}
          {homework.attachmentUrl && (
            <div className="mb-6">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Reference Diagram / Worksheet:
              </span>
              <img
                src={homework.attachmentUrl}
                alt={homework.title}
                className="max-h-72 object-contain rounded-lg border border-slate-300 mx-auto"
              />
            </div>
          )}

          {/* Lined Workspace for Handwritten Answers */}
          <div className="mb-8">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
              Student Answers / Working Area:
            </span>
            <div className="space-y-6 pt-2">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="border-b border-slate-300 w-full h-2"></div>
              ))}
            </div>
          </div>

          {/* Teacher Signature & Remarks Footer */}
          <div className="grid grid-cols-2 gap-8 pt-6 border-t-2 border-slate-800 text-xs">
            <div>
              <p className="font-bold text-slate-700 mb-6">Teacher's Remarks / Feedback:</p>
              <div className="border-b border-dotted border-slate-400 w-full mb-3"></div>
              <div className="border-b border-dotted border-slate-400 w-full"></div>
            </div>
            <div className="text-right flex flex-col justify-end">
              <p className="font-bold text-slate-800">Teacher's Signature & Date</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
