import React, { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface Props {
  lang: 'en' | 'ta';
}

export const PWAInstallButton: React.FC<Props> = ({ lang }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 rounded-full bg-linear-to-r from-emerald-500 to-teal-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-md hover:from-emerald-600 hover:to-teal-700 active:scale-95 transition"
        title="Install TuitionFlow App on your device"
      >
        <Download className="w-3.5 h-3.5" />
        <span>{lang === 'ta' ? 'செயலியை நிறுவு' : 'Install App'}</span>
      </button>
    );
  }

  // iOS Safari flow (beforeinstallprompt is not supported by WebKit)
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-full bg-linear-to-r from-teal-500 to-emerald-600 px-3 py-1.5 text-xs font-medium text-white shadow-sm hover:opacity-90 active:scale-95 transition"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>{lang === 'ta' ? 'போனில் சேர்க்க' : 'Add to Phone'}</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <div className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl border border-slate-100 text-slate-800">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-blue-100 text-blue-600 rounded-xl">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900">
                    {lang === 'ta' ? 'ஐபோனில் நிறுவ' : 'Install on iPhone / iPad'}
                  </h3>
                </div>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded-full text-slate-400 hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 space-y-3 text-sm text-slate-600">
                <p className="flex items-start gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-600 text-[11px] font-bold text-white">
                    1
                  </span>
                  <span>
                    {lang === 'ta'
                      ? 'சஃபாரி (Safari) கீழே உள்ள பகிர் (Share) பொத்தானைத் தட்டவும்.'
                      : 'Tap the Share icon at the bottom of Safari.'}
                  </span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-600 text-[11px] font-bold text-white">
                    2
                  </span>
                  <span>
                    {lang === 'ta'
                      ? 'கீழே உருட்டி "முகப்புத் திரையில் சேர்" (Add to Home Screen) என்பதைத் தேர்வு செய்யவும்.'
                      : 'Scroll down and tap "Add to Home Screen".'}
                  </span>
                </p>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-6 w-full rounded-xl bg-blue-600 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 transition"
              >
                {lang === 'ta' ? 'புரிந்தது' : 'Got it!'}
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
