import React from 'react';
import {
  X,
  Database,
  Smartphone,
  Laptop,
  CheckCircle2,
  Share2,
  ExternalLink,
  ShieldCheck,
  Zap,
  HelpCircle,
} from 'lucide-react';
import { Language, Translations } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  t: Translations;
}

export const SetupGuideModal: React.FC<Props> = ({ isOpen, onClose, lang, t }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-100 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-linear-to-r from-blue-600 via-indigo-600 to-teal-500 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-xs">
              <HelpCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg">
                {lang === 'ta' ? 'அமைப்பு & நேரலை வழிகாட்டி' : 'Setup & Live Sharing Guide'}
              </h3>
              <p className="text-xs text-blue-100">
                {lang === 'ta' ? 'மடிக்கணினி & செல்போன்களில் உடனுக்குடன் ஒத்திசைவு' : 'Live cloud synchronization between laptop & phones'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white/80 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto text-slate-700 text-xs sm:text-sm">
          {/* Status banner */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-emerald-900 text-sm">
                {t.databaseConnected}
              </h4>
              <p className="text-emerald-700 text-xs mt-0.5">
                {t.backendConfigNotice}
              </p>
            </div>
          </div>

          {/* How It Works Section */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-500" />
              {lang === 'ta' ? 'இது எவ்வாறு செயல்படுகிறது?' : 'How TuitionFlow AI Works'}
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200/80">
                <div className="flex items-center gap-2 font-bold text-blue-900 mb-1">
                  <Laptop className="w-4 h-4 text-blue-600" />
                  <span>{lang === 'ta' ? '1. ஆசிரியர் மடிக்கணினி' : '1. Teacher on Laptop / PC'}</span>
                </div>
                <p className="text-xs text-blue-800 leading-relaxed">
                  {lang === 'ta'
                    ? 'மாணவர்களைச் சேருங்கள், வீட்டுப்பாடங்களை உருவாக்கி மாணவர்களுக்கு ஒதுக்கீடு செய்யுங்கள், வரும் விடைகளை மதிப்பாய்வு செய்து பாராட்டுங்கள் அல்லது திருத்தங்கள் கேளுங்கள்.'
                    : 'Manage student roster, assign homework with instructions & due dates, review submitted answers, approve work or request corrections.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-teal-50/60 border border-teal-200/80">
                <div className="flex items-center gap-2 font-bold text-teal-900 mb-1">
                  <Smartphone className="w-4 h-4 text-teal-600" />
                  <span>{lang === 'ta' ? '2. மாணவர் செல்போன்' : "2. Student on Mobile Phone"}</span>
                </div>
                <p className="text-xs text-teal-800 leading-relaxed">
                  {lang === 'ta'
                    ? 'மாணவர்கள் தங்கள் தனிப்பட்ட குறியீட்டைப் பயன்படுத்தி அல்லது நேரடி இணைப்பை கிளிக் செய்து வீட்டுப்பாடத்தை பார்த்து, விடைகளை தட்டச்சு செய்து அல்லது படம் எடுத்து சமர்ப்பிக்கலாம்.'
                    : 'Students open their direct link (e.g. ?student=STU-101), type answers in Tamil/English, upload notebook photos, and submit with celebratory confetti!'}
                </p>
              </div>
            </div>
          </div>

          {/* How to Share with Students */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <Share2 className="w-4 h-4 text-indigo-600" />
              {lang === 'ta' ? 'மாணவர்களுடன் பகிர்வது எப்படி?' : 'How to Share with Students'}
            </h4>
            <ol className="list-decimal list-inside space-y-1.5 text-slate-600 text-xs">
              <li>
                {lang === 'ta'
                  ? 'ஆசிரியர் டாஷ்போர்டில் மாணவர் அட்டைக்குச் சென்று "மாணவர் நேரடி இணைப்பை நகலெடு" பொத்தானைக் கிளிக் செய்யவும்.'
                  : 'On the Teacher Dashboard, go to any student card and click "Copy Direct Student Portal Link".'}
              </li>
              <li>
                {lang === 'ta'
                  ? 'அந்த இணைப்பை வாட்ஸ்அப் (WhatsApp) மூலம் பெற்றோரின் செல்போனுக்கு அனுப்பவும்.'
                  : 'Send that link to the parent or student via WhatsApp or SMS.'}
              </li>
              <li>
                {lang === 'ta'
                  ? 'மாணவர் அந்த இணைப்பைத் திறக்கும்போது அவர் பெயர் & அவருக்கு ஒதுக்கப்பட்ட வீட்டுப்பாடங்கள் மட்டுமே தோன்றும்.'
                  : "When opened on the student's phone, they are directly logged in to their private portal with only their assignments visible."}
              </li>
            </ol>
          </div>

          {/* Security & Rules */}
          <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-200/80 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <h5 className="font-bold text-indigo-900 text-xs">
                {lang === 'ta' ? 'பாதுகாப்பு & தனிவுரிமை' : 'Zero-Trust Security & Data Isolation'}
              </h5>
              <p className="text-indigo-800 text-[11px] mt-0.5">
                {lang === 'ta'
                  ? 'ஃபயர்ஸ்டோர் விதிகள் மூலம் ஒவ்வொரு மாணவரும் தனது வீட்டுப்பாடங்களை மட்டுமே பார்க்க முடியும். பிற மாணவர்களின் விடைகளையோ பெயர்களையோ அணுக முடியாது.'
                  : 'Backend Firestore rules ensure students can only query their own homework and submissions. No API keys are leaked.'}
              </p>
            </div>
          </div>

          {/* Publishing Information */}
          <div className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-1.5">
            <h5 className="font-bold text-amber-900 text-xs">
              {lang === 'ta' ? 'இணையதளமாக வெளியிடுவது (Publishing & Free Tier)' : 'Publishing & Public Free Tier'}
            </h5>
            <p className="text-amber-800 text-xs leading-relaxed">
              {lang === 'ta'
                ? 'கூகிள் AI ஸ்டுடியோ மூலம் இந்த செயலி கிளவுட் ரன் மற்றும் ஃபயர்பேஸ் இலவச அடுக்கு (Free Tier) மூலம் இயங்குகிறது. பகிரப்பட்ட இணைப்பை (Shared App URL) யாருக்கு வேண்டுமானாலும் பகிரலாம்.'
                : 'This prototype runs on Google Cloud Run and Firebase Spark Free Tier (50,000 free reads/day). You can share the Shared App URL with all your tuition students without paying anything.'}
            </p>
          </div>

          <div className="pt-2 text-right">
            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-blue-600 text-white font-bold text-xs shadow-md hover:bg-blue-700 transition"
            >
              {lang === 'ta' ? 'புரிந்தது, மூடுக' : 'Got it, Close'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
