import React, { useState } from 'react';
import {
  Users,
  BookOpen,
  PlusCircle,
  FileCheck,
  Search,
  Filter,
  GraduationCap,
  Sparkles,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Student, Homework, Submission, Language, Translations } from '../types';
import { StudentCard } from './StudentCard';
import { HomeworkCard } from './HomeworkCard';
import { SubmissionsList } from './SubmissionsList';

interface Props {
  students: Student[];
  homeworks: Homework[];
  submissions: Submission[];
  lang: Language;
  t: Translations;
  onAddStudent: () => void;
  onEditStudent: (student: Student) => void;
  onDeleteStudent: (studentId: string) => void;
  onCreateHomework: () => void;
  onEditHomework: (homework: Homework) => void;
  onDeleteHomework: (homeworkId: string) => void;
  onPrintHomework: (homework: Homework) => void;
  onOpenAsStudent: (student: Student) => void;
  onUpdateSubmissionStatus: (submissionId: string, status: 'approved' | 'needs_correction', feedback: string) => Promise<void>;
}

export const TeacherDashboard: React.FC<Props> = ({
  students,
  homeworks,
  submissions,
  lang,
  t,
  onAddStudent,
  onEditStudent,
  onDeleteStudent,
  onCreateHomework,
  onEditHomework,
  onDeleteHomework,
  onPrintHomework,
  onOpenAsStudent,
  onUpdateSubmissionStatus,
}) => {
  const [activeTab, setActiveTab] = useState<'students' | 'assigned' | 'submissions'>('students');
  const [searchStudent, setSearchStudent] = useState('');
  const [selectedClass, setSelectedClass] = useState('all');
  const [filterHomeworkIdForSubmissions, setFilterHomeworkIdForSubmissions] = useState<string | null>(null);

  // Stats calculation
  const totalStudents = students.length;
  const activeAssignments = homeworks.length;
  const pendingReviews = submissions.filter((s) => s.status === 'submitted').length;
  const approvedCount = submissions.filter((s) => s.status === 'approved').length;

  const totalAssignedSlots = homeworks.reduce((acc, h) => acc + h.assignedStudentIds.length, 0);
  const totalCompletedSlots = submissions.filter(
    (s) => s.status === 'approved' || s.status === 'submitted'
  ).length;
  const overallRate = totalAssignedSlots > 0 ? Math.round((totalCompletedSlots / totalAssignedSlots) * 100) : 0;

  // Filter students
  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchStudent.toLowerCase()) ||
      s.studentCode.toLowerCase().includes(searchStudent.toLowerCase());
    const matchesClass = selectedClass === 'all' || s.grade === selectedClass;
    return matchesSearch && matchesClass;
  });

  // Extract unique classes
  const uniqueClasses = Array.from(new Set(students.map((s) => s.grade))).sort();

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Banner & Quick Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Students */}
        <div className="bg-white rounded-3xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              {t.totalStudents}
            </span>
            <span className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 block">
              {totalStudents}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Users className="w-6 h-6" />
          </div>
        </div>

        {/* Active Assignments */}
        <div className="bg-white rounded-3xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              {t.activeAssignments}
            </span>
            <span className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 block">
              {activeAssignments}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <BookOpen className="w-6 h-6" />
          </div>
        </div>

        {/* Pending Reviews */}
        <div className="bg-white rounded-3xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wider block">
              {t.pendingReviews}
            </span>
            <span className="text-2xl sm:text-3xl font-black text-amber-900 mt-1 block">
              {pendingReviews}
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        {/* Approved Homework & Rate */}
        <div className="bg-white rounded-3xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider block">
              {t.approvedCount}
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl sm:text-3xl font-black text-emerald-900">
                {approvedCount}
              </span>
              <span className="text-xs font-bold text-emerald-700">({overallRate}%)</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Action Header: Tabs & Create Buttons */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-4 sm:p-5 shadow-xs flex flex-wrap items-center justify-between gap-3">
        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1.5 rounded-2xl border border-slate-200/60">
          <button
            onClick={() => setActiveTab('students')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'students'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>{t.students}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-slate-200/70 text-[10px]">
              {students.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('assigned')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'assigned'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>{t.assignedHomework}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-slate-200/70 text-[10px]">
              {homeworks.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('submissions')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
              activeTab === 'submissions'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileCheck className="w-4 h-4" />
            <span>{t.submissions}</span>
            {pendingReviews > 0 ? (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-white text-[10px] animate-pulse">
                {pendingReviews}
              </span>
            ) : (
              <span className="px-1.5 py-0.2 rounded-full bg-slate-200/70 text-[10px]">
                {submissions.length}
              </span>
            )}
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={onAddStudent}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 transition active:scale-95"
          >
            <PlusCircle className="w-4 h-4 text-blue-600" />
            <span>{t.addStudent}</span>
          </button>

          <button
            onClick={onCreateHomework}
            className="flex items-center gap-2 px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-extrabold bg-linear-to-r from-blue-600 via-indigo-600 to-teal-600 text-white shadow-md shadow-blue-500/20 hover:opacity-95 active:scale-95 transition"
          >
            <Sparkles className="w-4 h-4" />
            <span>{t.createHomework}</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Students Section */}
      {activeTab === 'students' && (
        <div className="space-y-5">
          {/* Search & Class Filter */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs">
            <div className="relative flex-1 min-w-[240px]">
              <input
                type="text"
                value={searchStudent}
                onChange={(e) => setSearchStudent(e.target.value)}
                placeholder={t.searchStudent}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-xs sm:text-sm text-slate-800 outline-hidden transition"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3 pointer-events-none" />
            </div>

            {/* Class Grouping Filter */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500 hidden sm:inline">
                <Filter className="w-3.5 h-3.5 inline mr-1" />
                {lang === 'ta' ? 'வகுப்பு:' : 'Class:'}
              </span>
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-700 bg-white outline-hidden"
              >
                <option value="all">{t.allGrades}</option>
                {uniqueClasses.map((cls) => (
                  <option key={cls} value={cls}>
                    {cls}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Student Cards Grid */}
          {filteredStudents.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8">
              <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-bold text-slate-800 text-base">
                {lang === 'ta' ? 'மாணவர்கள் யாரும் பொருந்தவில்லை' : 'No Students Found'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {lang === 'ta'
                  ? 'புதிய மாணவரைச் சேர்க்க மேலே உள்ள "மாணவர் சேர்க்க" பொத்தானைக் கிளிக் செய்யவும்.'
                  : 'Click "Add Student" above to enroll students into the tuition portal.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredStudents.map((student) => (
                <StudentCard
                  key={student.id}
                  student={student}
                  homeworks={homeworks}
                  submissions={submissions}
                  lang={lang}
                  t={t}
                  onEdit={onEditStudent}
                  onDelete={onDeleteStudent}
                  onOpenAsStudent={onOpenAsStudent}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Assigned Homework Section */}
      {activeTab === 'assigned' && (
        <div className="space-y-5">
          {homeworks.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8">
              <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="font-bold text-slate-800 text-base">{t.noHomeworkFound}</h3>
              <p className="text-xs text-slate-500 mt-1 mb-4">
                {lang === 'ta'
                  ? 'மாணவர்களுக்கு புதிய வீட்டுப்பாடம் ஒதுக்கீடு செய்ய "வீட்டுப்பாடம் உருவாக்குக" பொத்தானைத் தட்டவும்.'
                  : 'Click "Create Homework" to assign daily tuition tasks to your students.'}
              </p>
              <button
                onClick={onCreateHomework}
                className="px-5 py-2.5 rounded-2xl text-xs font-bold bg-blue-600 text-white shadow-md hover:bg-blue-700 transition"
              >
                {t.createHomework}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {homeworks.map((hw) => (
                <HomeworkCard
                  key={hw.id}
                  homework={hw}
                  students={students}
                  submissions={submissions}
                  lang={lang}
                  t={t}
                  onEdit={onEditHomework}
                  onDelete={onDeleteHomework}
                  onPrint={onPrintHomework}
                  onViewSubmissions={(hwId) => {
                    setFilterHomeworkIdForSubmissions(hwId);
                    setActiveTab('submissions');
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Submissions Review Section */}
      {activeTab === 'submissions' && (
        <SubmissionsList
          submissions={submissions}
          homeworks={homeworks}
          students={students}
          lang={lang}
          t={t}
          onUpdateStatus={onUpdateSubmissionStatus}
          filterHomeworkId={filterHomeworkIdForSubmissions}
          onClearFilterHomework={() => setFilterHomeworkIdForSubmissions(null)}
        />
      )}
    </div>
  );
};
