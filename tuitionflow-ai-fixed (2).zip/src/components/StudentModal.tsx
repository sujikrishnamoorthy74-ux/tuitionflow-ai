import React, { useState, useEffect } from 'react';
import { X, UserPlus, Save, GraduationCap, Phone, Key, Sparkles } from 'lucide-react';
import { Student, Language, Translations } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (student: Student) => Promise<void>;
  editingStudent: Student | null;
  existingStudentsCount: number;
  lang: Language;
  t: Translations;
}

export const StudentModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSave,
  editingStudent,
  existingStudentsCount,
  lang,
  t,
}) => {
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('Class 8');
  const [parentPhone, setParentPhone] = useState('');
  const [studentCode, setStudentCode] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (editingStudent) {
      setName(editingStudent.name);
      setGrade(editingStudent.grade);
      setParentPhone(editingStudent.parentPhone || '');
      setStudentCode(editingStudent.studentCode);
    } else {
      setName('');
      setGrade('Class 8');
      setParentPhone('');
      // Auto-generate next friendly code e.g. STU-105
      const nextNum = 101 + existingStudentsCount;
      setStudentCode(`STU-${nextNum}`);
    }
    setError('');
  }, [editingStudent, existingStudentsCount, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError(lang === 'ta' ? 'மாணவர் பெயரை உள்ளிடவும்' : 'Please enter student name');
      return;
    }
    if (!studentCode.trim()) {
      setError(lang === 'ta' ? 'மாணவர் குறியீட்டை உள்ளிடவும்' : 'Please enter student code');
      return;
    }

    setSaving(true);
    try {
      const studentToSave: Student = {
        id: editingStudent ? editingStudent.id : `student-${Date.now()}`,
        name: name.trim(),
        grade: grade.trim(),
        studentCode: studentCode.trim().toUpperCase(),
        createdAt: editingStudent ? editingStudent.createdAt : new Date().toISOString(),
      };
      if (parentPhone.trim()) {
        studentToSave.parentPhone = parentPhone.trim();
      }

      await onSave(studentToSave);
      onClose();
    } catch (err) {
      setError(String(err));
    } finally {
      setSaving(false);
    }
  };

  const gradesList = ['Class 5', 'Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10', 'Class 11', 'Class 12'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden">
        {/* Header */}
        <div className="bg-linear-to-r from-blue-600 via-indigo-600 to-teal-500 px-6 py-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-xs">
              <UserPlus className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg">
                {editingStudent ? t.editStudent : t.addStudent}
              </h3>
              <p className="text-xs text-blue-100">
                {lang === 'ta'
                  ? 'மாணவர் பெயர் & குறியீட்டு விவரங்கள்'
                  : 'Enroll student with direct access code'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white/80 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 font-medium">
              {error}
            </div>
          )}

          {/* Student Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.studentName} <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={lang === 'ta' ? 'எ.கா. கவின் ராஜா / Kavin Raja' : 'e.g. Kavin Raja'}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-sm font-medium text-slate-800 outline-hidden transition"
              required
            />
          </div>

          {/* Grade / Class */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.gradeClass}
            </label>
            <div className="relative">
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-sm font-medium text-slate-800 outline-hidden transition appearance-none bg-white"
              >
                {gradesList.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
              <GraduationCap className="w-4 h-4 text-slate-400 absolute right-3.5 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Student Access Code */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-700">
                {t.studentCode} <span className="text-rose-500">*</span>
              </label>
              <span className="text-[10px] text-indigo-600 font-medium flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                {lang === 'ta' ? 'மாணவர் உள்நுழைவு குறியீடு' : 'Student login code'}
              </span>
            </div>
            <div className="relative">
              <input
                type="text"
                value={studentCode}
                onChange={(e) => setStudentCode(e.target.value.toUpperCase())}
                placeholder="e.g. STU-101"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-sm font-mono font-bold text-indigo-700 outline-hidden transition"
                required
              />
              <Key className="w-4 h-4 text-slate-400 absolute right-3.5 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Parent WhatsApp / Phone */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {t.parentPhone} ({lang === 'ta' ? 'விருப்பத்திற்குரியது' : 'Optional'})
            </label>
            <div className="relative">
              <input
                type="tel"
                value={parentPhone}
                onChange={(e) => setParentPhone(e.target.value)}
                placeholder="+91 98765 43210"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 text-sm font-medium text-slate-800 outline-hidden transition"
              />
              <Phone className="w-4 h-4 text-slate-400 absolute right-3.5 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-3 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
            >
              {t.cancel}
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-linear-to-r from-blue-600 to-indigo-600 text-white shadow-md hover:from-blue-700 hover:to-indigo-700 active:scale-95 disabled:opacity-50 transition"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : t.saveStudent}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
