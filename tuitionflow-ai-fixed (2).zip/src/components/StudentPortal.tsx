import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  BookOpen,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Upload,
  Send,
  Save,
  Bell,
  Volume2,
  VolumeX,
  Smartphone,
  LogOut,
  ChevronRight,
  Award,
  FileText,
  AlertTriangle,
  RotateCcw,
  Key,
  X,
  ExternalLink,
  Printer,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Student, Homework, Submission, Language, Translations } from '../types';
import { subjectTranslations } from '../locales/translations';
import {
  playGentleChime,
  triggerHapticVibrate,
  requestNotificationPermission,
  sendBrowserNotification,
} from '../utils/audioReminder';

interface Props {
  currentStudent: Student | null;
  students: Student[];
  homeworks: Homework[];
  submissions: Submission[];
  lang: Language;
  t: Translations;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onSelectStudent: (student: Student) => void;
  onLogoutStudent: () => void;
  onSaveSubmission: (submission: Submission) => Promise<void>;
  onPrintHomework: (homework: Homework) => void;
}

export const StudentPortal: React.FC<Props> = ({
  currentStudent,
  students,
  homeworks,
  submissions,
  lang,
  t,
  soundEnabled,
  onToggleSound,
  onSelectStudent,
  onLogoutStudent,
  onSaveSubmission,
  onPrintHomework,
}) => {
  // Input for student login code
  const [inputCode, setInputCode] = useState('');
  const [loginError, setLoginError] = useState('');

  // Active Homework Workspace Modal
  const [activeHomework, setActiveHomework] = useState<Homework | null>(null);
  const [activeSubmission, setActiveSubmission] = useState<Submission | null>(null);
  const [answerText, setAnswerText] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState<string | undefined>(undefined);
  const [submitting, setSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [tabFilter, setTabFilter] = useState<'all' | 'pending' | 'completed'>('pending');
  const [draftSavedToast, setDraftSavedToast] = useState(false);

  // Filter homework assigned to current student
  const myHomeworks = currentStudent
    ? homeworks.filter((h) => h.assignedStudentIds.includes(currentStudent.id))
    : [];

  const getStudentSubmission = (hwId: string): Submission | undefined => {
    if (!currentStudent) return undefined;
    return submissions.find((s) => s.homeworkId === hwId && s.studentId === currentStudent.id);
  };

  // Calculate student statistics
  const completedHws = myHomeworks.filter((hw) => {
    const sub = getStudentSubmission(hw.id);
    return sub && (sub.status === 'approved' || sub.status === 'submitted');
  });

  const pendingHws = myHomeworks.filter((hw) => {
    const sub = getStudentSubmission(hw.id);
    return !sub || sub.status === 'pending' || sub.status === 'needs_correction';
  });

  const completionPercent =
    myHomeworks.length > 0 ? Math.round((completedHws.length / myHomeworks.length) * 100) : 0;

  // Open homework solver modal
  const handleOpenSolver = (hw: Homework) => {
    setActiveHomework(hw);
    const existing = getStudentSubmission(hw.id);
    setActiveSubmission(existing || null);
    setAnswerText(existing?.draftAnswer || existing?.answer || '');
    setAttachmentUrl(existing?.attachmentUrl);

    // Provide soft interaction chime & haptic
    if (soundEnabled) {
      playGentleChime('alert');
    }
    triggerHapticVibrate([60]);
  };

  // Image upload handler
  const handleStudentImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2.5 * 1024 * 1024) {
      alert(lang === 'ta' ? 'படத்தின் அளவு 2.5MB-க்கு குறைவாக இருக்க வேண்டும்.' : 'File size must be under 2.5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setAttachmentUrl(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Save Progress (Draft)
  const handleSaveDraft = async () => {
    if (!activeHomework || !currentStudent) return;
    setSubmitting(true);
    try {
      const submissionId = activeSubmission?.id || `sub-${currentStudent.id}-${activeHomework.id}`;
      const updatedSub: Submission = {
        id: submissionId,
        homeworkId: activeHomework.id,
        studentId: currentStudent.id,
        studentName: currentStudent.name,
        answer: activeSubmission?.answer || '',
        draftAnswer: answerText,
        attachmentUrl,
        status: activeSubmission?.status || 'pending',
        teacherFeedback: activeSubmission?.teacherFeedback,
        submittedAt: activeSubmission?.submittedAt,
        updatedAt: new Date().toISOString(),
      };

      await onSaveSubmission(updatedSub);
      setActiveSubmission(updatedSub);
      setDraftSavedToast(true);
      triggerHapticVibrate([80]);
      setTimeout(() => setDraftSavedToast(false), 3000);
    } finally {
      setSubmitting(false);
    }
  };

  // Submit Final Homework
  const handleSubmitFinal = async () => {
    if (!activeHomework || !currentStudent) return;
    if (!answerText.trim() && !attachmentUrl) {
      alert(
        lang === 'ta'
          ? 'தயவுசெய்து உங்கள் விடையை எழுதவும் அல்லது படத்தை பதிவேற்றவும்!'
          : 'Please enter your written answer or attach a photo before submitting!'
      );
      return;
    }

    setSubmitting(true);
    try {
      const submissionId = activeSubmission?.id || `sub-${currentStudent.id}-${activeHomework.id}`;
      const finalSub: Submission = {
        id: submissionId,
        homeworkId: activeHomework.id,
        studentId: currentStudent.id,
        studentName: currentStudent.name,
        answer: answerText.trim(),
        draftAnswer: '',
        attachmentUrl,
        status: 'submitted',
        teacherFeedback: activeSubmission?.teacherFeedback,
        submittedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await onSaveSubmission(finalSub);
      setActiveSubmission(finalSub);
      setActiveHomework(null);

      // Play joyful celebration sound & vibration
      if (soundEnabled) {
        playGentleChime('success');
      }
      triggerHapticVibrate([100, 50, 150]);

      // Trigger Confetti Celebration
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#2563EB', '#7C3AED', '#0D9488', '#F59E0B', '#10B981'],
      });

      setShowSuccessModal(true);
    } finally {
      setSubmitting(false);
    }
  };

  // Code login
  const handleCodeLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = inputCode.trim().toUpperCase();
    const found = students.find(
      (s) => s.studentCode.toUpperCase() === clean || s.name.toUpperCase().includes(clean)
    );
    if (found) {
      onSelectStudent(found);
      setInputCode('');
      setLoginError('');
      if (soundEnabled) playGentleChime('alert');
    } else {
      setLoginError(
        lang === 'ta'
          ? 'மாணவர் குறியீடு கிடைக்கவில்லை. சரியான குறியீட்டை உள்ளிடவும் (எ.கா. STU-101).'
          : 'Student code not found. Please enter a valid code (e.g. STU-101).'
      );
    }
  };

  // If no student is selected, display Student Access / Login Screen
  if (!currentStudent) {
    return (
      <div className="max-w-md mx-auto py-8 px-4">
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden p-6 sm:p-8 text-center relative">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-linear-to-tr from-blue-600 via-indigo-600 to-teal-500 text-white flex items-center justify-center shadow-lg shadow-blue-500/25 mb-5">
            <Sparkles className="w-10 h-10" />
          </div>

          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            {t.studentPortal}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1.5 mb-6">
            {t.studentLoginPrompt}
          </p>

          {loginError && (
            <div className="mb-4 p-3 rounded-2xl bg-rose-50 border border-rose-200 text-xs font-semibold text-rose-700 flex items-center gap-2 text-left">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleCodeLogin} className="space-y-4">
            <div className="relative">
              <input
                type="text"
                value={inputCode}
                onChange={(e) => setInputCode(e.target.value)}
                placeholder="e.g. STU-101"
                className="w-full px-4 py-3.5 rounded-2xl border-2 border-slate-200 focus:border-blue-600 focus:ring-4 focus:ring-blue-100 text-center text-lg font-mono font-black text-indigo-700 uppercase tracking-widest outline-hidden transition"
                required
              />
              <Key className="w-5 h-5 text-slate-400 absolute left-4 top-4 pointer-events-none" />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 px-6 rounded-2xl bg-linear-to-r from-blue-600 via-indigo-600 to-teal-600 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-blue-500/30 hover:opacity-95 active:scale-98 transition flex items-center justify-center gap-2"
            >
              <span>{t.loginAsStudent}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Demo Switcher helper for immediate testing */}
          <div className="mt-8 pt-6 border-t border-slate-100 text-left">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2.5">
              {lang === 'ta' ? 'சோதனைக்கு மாணவரைத் தேர்ந்தெடுக்கவும்:' : 'Or tap a demo student to test:'}
            </span>
            <div className="grid grid-cols-1 gap-2">
              {students.slice(0, 4).map((s) => (
                <button
                  key={s.id}
                  onClick={() => onSelectStudent(s)}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 hover:border-blue-400 bg-slate-50 hover:bg-blue-50/50 transition text-left group"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-7 h-7 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                      {s.name.charAt(0)}
                    </span>
                    <span className="text-xs font-bold text-slate-800 truncate">
                      {s.name}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100 shrink-0">
                    {s.studentCode}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Filter displayed homeworks by tab
  const displayedHws = myHomeworks.filter((hw) => {
    const sub = getStudentSubmission(hw.id);
    const isDone = sub && (sub.status === 'approved' || sub.status === 'submitted');
    if (tabFilter === 'pending') return !isDone;
    if (tabFilter === 'completed') return isDone;
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Student Welcome Header Card */}
      <div className="bg-linear-to-r from-blue-600 via-indigo-600 to-teal-500 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        {/* Background Decorative Rings */}
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-white/10 blur-xl pointer-events-none" />
        <div className="absolute right-20 -bottom-16 w-40 h-40 rounded-full bg-teal-400/20 blur-lg pointer-events-none" />

        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-3xl bg-white text-blue-700 font-black text-2xl flex items-center justify-center shadow-lg shrink-0">
              {currentStudent.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight">
                  {lang === 'ta' ? `வணக்கம், ${currentStudent.name}! 🌟` : `Welcome, ${currentStudent.name}! 🌟`}
                </h1>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-white/20 backdrop-blur-xs">
                  {currentStudent.grade}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-white/20 backdrop-blur-xs">
                  {currentStudent.studentCode}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onLogoutStudent}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold bg-white/15 hover:bg-white/25 text-white backdrop-blur-xs transition"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{t.logout}</span>
            </button>
          </div>
        </div>

        {/* Motivational Quote */}
        <p className="mt-4 pt-4 border-t border-white/20 text-xs sm:text-sm text-blue-100 font-medium">
          {lang === 'ta'
            ? '“கற்க கசடறக் கற்பவை கற்றபின் நிற்க அதற்குத் தக” — தினசரி வீட்டுப்பாடம் உங்கள் வெற்றிக்கான படிக்கட்டு!'
            : '“Learning is a superpower!” Complete your homework today to shine bright tomorrow 🚀'}
        </p>

        {/* Progress Bar in Welcome Card */}
        <div className="mt-5 bg-white/15 rounded-2xl p-4 backdrop-blur-xs">
          <div className="flex items-center justify-between text-xs font-bold mb-1.5">
            <span>{t.progressLabel}</span>
            <span>
              {completedHws.length} / {myHomeworks.length} ({completionPercent}%)
            </span>
          </div>
          <div className="w-full bg-black/20 h-3 rounded-full overflow-hidden">
            <div
              className="bg-linear-to-r from-amber-300 to-teal-300 h-full rounded-full transition-all duration-700"
              style={{ width: `${completionPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Homework Reminders Banner (Section 4) */}
      {pendingHws.length > 0 && (
        <div className="bg-amber-50 border-2 border-amber-300/80 rounded-3xl p-5 shadow-sm text-amber-950 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-amber-950 flex items-center justify-center shrink-0 animate-bounce">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-sm sm:text-base">
                {lang === 'ta'
                  ? `உங்களுக்கு ${pendingHws.length} வீட்டுப்பாடம் முடிக்கப்படாமல் உள்ளது!`
                  : `You have ${pendingHws.length} pending homework assignment${pendingHws.length > 1 ? 's' : ''}!`}
              </h4>
              <p className="text-xs text-amber-800 mt-0.5">
                {t.reminderNotice}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onToggleSound();
                playGentleChime('reminder');
                triggerHapticVibrate([100]);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
                soundEnabled
                  ? 'bg-amber-200/80 border-amber-400 text-amber-900'
                  : 'bg-white border-amber-300 text-amber-800'
              }`}
              title="Test reminder chime sound"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-800" /> : <VolumeX className="w-4 h-4 text-amber-600" />}
              <span>{soundEnabled ? t.reminderSoundOn : t.reminderSoundOff}</span>
            </button>
            <button
              onClick={async () => {
                const granted = await requestNotificationPermission();
                if (granted) {
                  sendBrowserNotification(
                    'TuitionFlow AI Reminder',
                    lang === 'ta' ? 'உங்கள் வீட்டுப்பாடத்தை சரியான நேரத்தில் முடிக்கவும்!' : 'Submit your homework on time!'
                  );
                }
              }}
              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white shadow-xs transition"
              title="Enable browser reminder notifications"
            >
              🔔 {lang === 'ta' ? 'அறிவிப்பு' : 'Notify Me'}
            </button>
          </div>
        </div>
      )}

      {/* Tabs Filter Bar */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setTabFilter('pending')}
            className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${
              tabFilter === 'pending'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>{t.pendingStatus}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
              {pendingHws.length}
            </span>
          </button>
          <button
            onClick={() => setTabFilter('completed')}
            className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition flex items-center gap-1.5 ${
              tabFilter === 'completed'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{t.completedTasks}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
              {completedHws.length}
            </span>
          </button>
          <button
            onClick={() => setTabFilter('all')}
            className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition ${
              tabFilter === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {lang === 'ta' ? 'அனைத்தும்' : 'All'} ({myHomeworks.length})
          </button>
        </div>
      </div>

      {/* Homework Cards Grid */}
      {displayedHws.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8">
          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="font-extrabold text-slate-900 text-base sm:text-lg">
            {tabFilter === 'pending'
              ? (lang === 'ta' ? 'அருமை! நீங்கள் அனைத்து வீட்டுப்பாடங்களையும் முடித்துவிட்டீர்கள்! 🎉' : 'Hurray! No pending homework! You are all caught up! 🎉')
              : t.noHomeworkFound}
          </h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {lang === 'ta'
              ? 'புதிய வீட்டுப்பாடங்கள் ஆசிரியர் வழங்கியதும் இங்கே தெரியும்.'
              : 'New assignments assigned by your teacher will appear here.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {displayedHws.map((hw) => {
            const sub = getStudentSubmission(hw.id);
            const subMeta = subjectTranslations[hw.subject] || subjectTranslations.Tamil;

            const isApproved = sub?.status === 'approved';
            const isSubmitted = sub?.status === 'submitted';
            const isCorrection = sub?.status === 'needs_correction';
            const isPending = !sub || sub.status === 'pending';

            const today = new Date().toISOString().split('T')[0];
            const isOverdue = hw.dueDate < today && isPending;

            return (
              <div
                key={hw.id}
                className={`bg-white rounded-3xl border p-5 sm:p-6 shadow-sm hover:shadow-md transition-all flex flex-col justify-between relative overflow-hidden ${
                  isCorrection
                    ? 'border-rose-300 ring-2 ring-rose-100'
                    : isApproved
                    ? 'border-emerald-300 ring-2 ring-emerald-100'
                    : 'border-slate-200'
                }`}
              >
                {/* Subject color bar */}
                <div className={`absolute top-0 left-0 right-0 h-1.5 ${subMeta.iconBg}`} />

                <div>
                  {/* Top tags: Subject & Status */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${subMeta.color}`}
                    >
                      <span className={`w-2 h-2 rounded-full ${subMeta.iconBg}`} />
                      <span>{lang === 'ta' ? subMeta.ta : subMeta.en}</span>
                    </span>

                    {/* Status Badge */}
                    <div>
                      {isApproved && (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{t.approvedStatus}</span>
                        </span>
                      )}
                      {isCorrection && (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300 animate-pulse">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>{t.needsCorrectionStatus}</span>
                        </span>
                      )}
                      {isSubmitted && (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-300">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{t.submittedStatus}</span>
                        </span>
                      )}
                      {isPending && isOverdue && (
                        <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300 animate-pulse">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>{t.overdue}</span>
                        </span>
                      )}
                      {isPending && !isOverdue && (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-slate-500">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{hw.dueDate}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="font-extrabold text-slate-900 text-base sm:text-lg mb-2">
                    {hw.title}
                  </h3>

                  {/* Instructions Preview */}
                  <p className="text-xs sm:text-sm text-slate-600 line-clamp-3 bg-slate-50 p-3 rounded-2xl border border-slate-100 whitespace-pre-line mb-3">
                    {hw.instructions}
                  </p>

                  {/* Teacher Feedback if Correction Requested */}
                  {isCorrection && sub?.teacherFeedback && (
                    <div className="mb-3 p-3 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800">
                      <span className="font-bold flex items-center gap-1 mb-1 text-rose-900">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {t.teacherFeedbackLabel}:
                      </span>
                      <p className="italic font-medium">"{sub.teacherFeedback}"</p>
                    </div>
                  )}

                  {/* Teacher Feedback if Approved */}
                  {isApproved && sub?.teacherFeedback && (
                    <div className="mb-3 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800">
                      <span className="font-bold flex items-center gap-1 mb-1 text-emerald-900">
                        <Award className="w-3.5 h-3.5" />
                        {t.teacherFeedbackLabel}:
                      </span>
                      <p className="italic font-medium">"{sub.teacherFeedback}"</p>
                    </div>
                  )}
                </div>

                {/* Footer Action Button */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => onPrintHomework(hw)}
                    className="p-2.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition"
                    title={t.printWorksheet}
                  >
                    <Printer className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleOpenSolver(hw)}
                    className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-2xl text-xs sm:text-sm font-extrabold shadow-md active:scale-98 transition ${
                      isCorrection
                        ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-500/25'
                        : isApproved
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-500/25'
                        : isSubmitted
                        ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-500/25'
                        : 'bg-linear-to-r from-blue-600 via-indigo-600 to-teal-600 hover:opacity-95 text-white shadow-blue-500/30'
                    }`}
                  >
                    {isCorrection ? (
                      <>
                        <RotateCcw className="w-4 h-4" />
                        <span>{t.resubmitHomework}</span>
                      </>
                    ) : isApproved ? (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{lang === 'ta' ? 'விடையைப் பார்க்க' : 'View Approved Work'}</span>
                      </>
                    ) : isSubmitted ? (
                      <>
                        <FileText className="w-4 h-4" />
                        <span>{lang === 'ta' ? 'சமர்ப்பித்த விடையைப் பார்க்க' : 'View Submitted Answer'}</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>{t.startHomework}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Homework Solver & Submission Modal (Section 3) */}
      {activeHomework && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-100 overflow-hidden my-6">
            {/* Header */}
            <div className="bg-linear-to-r from-blue-600 via-indigo-600 to-teal-500 px-6 py-5 text-white flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-teal-200">
                  {subjectTranslations[activeHomework.subject]?.en} • Due {activeHomework.dueDate}
                </span>
                <h3 className="font-extrabold text-lg sm:text-xl">
                  {activeHomework.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveHomework(null)}
                className="p-1.5 rounded-full hover:bg-white/20 text-white/80 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
              {/* Draft Saved Toast */}
              {draftSavedToast && (
                <div className="p-3 rounded-2xl bg-teal-50 border border-teal-300 text-teal-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-teal-600" />
                  <span>
                    {lang === 'ta'
                      ? 'விடைகள் வரைவாக (Draft) சேமிக்கப்பட்டது! நீங்கள் எப்போது வேண்டுமானாலும் தொடரலாம்.'
                      : 'Progress saved as draft! You can continue anytime.'}
                  </span>
                </div>
              )}

              {/* Teacher Instructions */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
                <span className="text-xs font-bold text-slate-700 block mb-1">
                  {lang === 'ta' ? 'ஆசிரியரின் வழிமுறைகள் & வினாக்கள்:' : 'Homework Instructions & Questions:'}
                </span>
                <p className="text-xs sm:text-sm text-slate-800 whitespace-pre-line leading-relaxed">
                  {activeHomework.instructions}
                </p>

                {activeHomework.attachmentUrl && (
                  <div className="mt-3">
                    <span className="text-[11px] font-bold text-slate-500 block mb-1">
                      {lang === 'ta' ? 'பணித்தாள் படம்:' : 'Attached Reference Worksheet:'}
                    </span>
                    <img
                      src={activeHomework.attachmentUrl}
                      alt="Worksheet Reference"
                      className="max-h-48 rounded-xl object-contain border border-slate-200"
                    />
                  </div>
                )}
              </div>

              {/* Teacher Feedback alert if needs correction */}
              {activeSubmission?.status === 'needs_correction' && activeSubmission.teacherFeedback && (
                <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800">
                  <span className="font-bold flex items-center gap-1.5 mb-1 text-rose-900">
                    <AlertCircle className="w-4 h-4" />
                    {t.teacherFeedbackLabel}:
                  </span>
                  <p className="font-medium italic">"{activeSubmission.teacherFeedback}"</p>
                </div>
              )}

              {/* Student Typed Answer */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-800">
                    {lang === 'ta' ? 'உங்கள் விடைகள் (தமிழ் அல்லது English):' : 'Your Written Answers:'}
                  </label>
                  <span className="text-[11px] text-slate-400">
                    {lang === 'ta' ? 'இங்கு தட்டச்சு செய்யலாம்' : 'Type or paste here'}
                  </span>
                </div>
                <textarea
                  rows={6}
                  value={answerText}
                  onChange={(e) => setAnswerText(e.target.value)}
                  placeholder={t.typeYourAnswer}
                  disabled={activeSubmission?.status === 'approved'}
                  className="w-full px-4 py-3 rounded-2xl border border-slate-300 focus:border-blue-500 focus:ring-4 focus:ring-blue-100 text-sm text-slate-800 outline-hidden transition leading-relaxed disabled:bg-slate-100"
                />
              </div>

              {/* Optional Photo Attachment */}
              {activeSubmission?.status !== 'approved' && (
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    {t.uploadPhoto}
                  </label>
                  {attachmentUrl ? (
                    <div className="relative inline-block border border-slate-200 rounded-2xl overflow-hidden p-1 bg-slate-50">
                      <img
                        src={attachmentUrl}
                        alt="Student work preview"
                        className="max-h-48 rounded-xl object-contain"
                      />
                      <button
                        type="button"
                        onClick={() => setAttachmentUrl(undefined)}
                        className="absolute top-2 right-2 p-1.5 rounded-full bg-rose-600 text-white text-xs shadow-md"
                        title="Remove photo"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-2xl cursor-pointer bg-slate-50/50 hover:bg-blue-50/30 transition">
                      <Upload className="w-6 h-6 text-slate-400 mb-1" />
                      <span className="text-xs font-bold text-slate-700">
                        {lang === 'ta' ? 'நோட்டுப் புத்தக புகைப்படத்தை பதிவேற்ற கிளிக் செய்க' : 'Take photo or upload notebook scan'}
                      </span>
                      <span className="text-[10px] text-slate-400 mt-0.5">JPG, PNG (max 2.5MB)</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleStudentImage}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
              )}

              {/* Modal Action Buttons */}
              <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2.5">
                <button
                  type="button"
                  onClick={() => setActiveHomework(null)}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
                >
                  {t.cancel}
                </button>

                {activeSubmission?.status !== 'approved' && (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={submitting}
                      onClick={handleSaveDraft}
                      className="flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-xs font-bold border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 active:scale-95 transition"
                    >
                      <Save className="w-4 h-4 text-slate-500" />
                      <span>{t.saveProgress}</span>
                    </button>

                    <button
                      type="button"
                      disabled={submitting}
                      onClick={handleSubmitFinal}
                      className="flex items-center gap-2 px-6 py-2.5 rounded-2xl text-xs font-extrabold bg-linear-to-r from-blue-600 via-indigo-600 to-teal-600 text-white shadow-lg shadow-blue-500/25 hover:opacity-95 active:scale-95 disabled:opacity-50 transition"
                    >
                      <Send className="w-4 h-4" />
                      <span>
                        {submitting
                          ? 'Submitting...'
                          : activeSubmission?.status === 'needs_correction'
                          ? t.resubmitHomework
                          : t.submitHomework}
                      </span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Submission Success Confirmation Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-in zoom-in-95 duration-200">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 text-center shadow-2xl border border-slate-100">
            <div className="w-16 h-16 mx-auto mb-4 rounded-3xl bg-linear-to-tr from-emerald-500 to-teal-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <h3 className="text-xl font-black text-slate-900">
              {lang === 'ta' ? 'அற்புதம்! சமர்ப்பிக்கப்பட்டது!' : 'Awesome Job! Submitted!'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-2">
              {t.submissionSuccess}
            </p>

            <button
              onClick={() => setShowSuccessModal(false)}
              className="mt-6 w-full py-3 rounded-2xl bg-linear-to-r from-emerald-600 to-teal-600 text-white font-extrabold text-xs sm:text-sm shadow-md hover:opacity-95 active:scale-98 transition"
            >
              {lang === 'ta' ? 'மகிழ்ச்சி! முடிந்தது' : 'Great, Done!'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
