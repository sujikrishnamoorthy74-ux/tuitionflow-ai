import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDocFromServer,
  collection,
  onSnapshot,
  setDoc,
  deleteDoc,
  query,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { Student, Homework, Submission } from '../types';

// 1. Initialize Firebase
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// CRITICAL: The app will break without the firestoreDatabaseId parameter!
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

// 2. Structured Error Handling as specified in Firebase Integration Skill
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo;
}

// 3. Test Connection on boot
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('Firebase Firestore connection verified.');
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or starting up.');
    } else {
      console.log('Firestore connection test note:', error);
    }
    return false;
  }
}

// 4. Initial Fictional Demo Data for Testing
export const INITIAL_DEMO_STUDENTS: Student[] = [
  {
    id: 'student-101',
    name: 'Kavin Raja (கவின் ராஜா)',
    studentCode: 'STU-101',
    grade: 'Class 8',
    parentPhone: '+91 98765 43210',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'student-102',
    name: 'Ananya Selvam (அனன்யா செல்வம்)',
    studentCode: 'STU-102',
    grade: 'Class 8',
    parentPhone: '+91 98451 23456',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'student-103',
    name: 'Karthik Murali (கார்த்திக் முரளி)',
    studentCode: 'STU-103',
    grade: 'Class 7',
    parentPhone: '+91 97890 12345',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'student-104',
    name: 'Divya Prakash (திவ்யா பிரகாஷ்)',
    studentCode: 'STU-104',
    grade: 'Class 9',
    parentPhone: '+91 94432 56789',
    createdAt: new Date().toISOString(),
  },
];

const tomorrow = new Date();
tomorrow.setDate(tomorrow.getDate() + 1);
const tomorrowStr = tomorrow.toISOString().split('T')[0];

const nextWeek = new Date();
nextWeek.setDate(nextWeek.getDate() + 4);
const nextWeekStr = nextWeek.toISOString().split('T')[0];

export const INITIAL_DEMO_HOMEWORKS: Homework[] = [
  {
    id: 'hw-tamil-1',
    title: 'திருக்குறள் மனப்பாடப் பகுதி & விளக்கம் (Thirukkural)',
    subject: 'Tamil',
    instructions:
      'அதிகாரம்: ஒழுக்கமுடைமை (அறத்துப்பால்). முதல் 3 குறள்களை எழுதி, அதன் சுருக்கமான பொருளை உங்கள் சொந்த நடையில் எழுதவும்.\n\nWrite the first 3 couplets from the chapter "Ozhukkamudaimai" and explain their core meaning in your own words.',
    dueDate: tomorrowStr,
    assignedStudentIds: ['student-101', 'student-102'],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'hw-maths-1',
    title: 'Fractions & Linear Equations Practice Set',
    subject: 'Maths',
    instructions:
      'Solve the following problems:\n1) Solve for x: 3x + 7 = 28\n2) Simplify: 3/4 + 5/6 - 1/2\n3) If the perimeter of a rectangle is 48cm and length is 14cm, find its breadth and area.',
    dueDate: nextWeekStr,
    assignedStudentIds: ['student-101', 'student-102', 'student-103'],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'hw-science-1',
    title: 'Photosynthesis & Plant Cell Structure',
    subject: 'Science',
    instructions:
      '1. Define photosynthesis and write the balanced chemical equation.\n2. List three differences between plant cell and animal cell.\n3. (Optional) Draw a neat diagram in your notebook and upload a photo.',
    dueDate: tomorrowStr,
    assignedStudentIds: ['student-101', 'student-104'],
    createdAt: new Date().toISOString(),
  },
];

export const INITIAL_DEMO_SUBMISSIONS: Submission[] = [
  {
    id: 'sub-sample-1',
    homeworkId: 'hw-tamil-1',
    studentId: 'student-101',
    studentName: 'Kavin Raja (கவின் ராஜா)',
    answer:
      '1. ஒழுக்கம் விழுப்பந் தரலான் ஒழுக்கம்\nஉயிரினும் ஓம்பப் படும்.\nவிளக்கம்: ஒழுக்கம் அனைவருக்கும் சிறப்பைத் தரும்; ஆதலால் அதனை உயிரை விட மேலானதாகக் காக்க வேண்டும்.\n\n2. பரிந்தோம்பிக் காக்க ஒழுக்கம் தெரிந்தோம்பித்\nதேரினும் அஃதே துணை.\nவிளக்கம்: எவ்வழியில் ஆராய்ந்து பார்த்தாலும் ஒழுக்கமே சிறந்த துணையாகும்.',
    status: 'submitted',
    submittedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// 5. Real-time Subscription Hooks and Data Operations
export function subscribeToStudents(callback: (students: Student[]) => void) {
  try {
    const cached = localStorage.getItem('tuitionflow_cached_students');
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        callback(parsed);
      }
    }
  } catch (e) {}

  const collRef = collection(db, 'students');
  return onSnapshot(
    query(collRef),
    (snapshot) => {
      const items: Student[] = [];
      snapshot.forEach((doc) => {
        items.push({ id: doc.id, ...(doc.data() as Omit<Student, 'id'>) });
      });
      if (items.length > 0) {
        try {
          localStorage.setItem('tuitionflow_cached_students', JSON.stringify(items));
        } catch (e) {}
        callback(items);
      } else {
        const cached = localStorage.getItem('tuitionflow_cached_students');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) {
            callback(parsed);
            return;
          }
        }
        callback(items);
      }
    },
    (err) => {
      handleFirestoreError(err, OperationType.GET, 'students');
      try {
        const cached = localStorage.getItem('tuitionflow_cached_students');
        if (cached) callback(JSON.parse(cached));
      } catch (e) {}
    }
  );
}

export function subscribeToHomeworks(callback: (homeworks: Homework[]) => void) {
  try {
    const cached = localStorage.getItem('tuitionflow_cached_homeworks');
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        callback(parsed);
      }
    }
  } catch (e) {}

  const collRef = collection(db, 'homeworks');
  return onSnapshot(
    query(collRef),
    (snapshot) => {
      const items: Homework[] = [];
      snapshot.forEach((doc) => {
        items.push({ id: doc.id, ...(doc.data() as Omit<Homework, 'id'>) });
      });
      if (items.length > 0) {
        try {
          localStorage.setItem('tuitionflow_cached_homeworks', JSON.stringify(items));
        } catch (e) {}
        callback(items);
      } else {
        const cached = localStorage.getItem('tuitionflow_cached_homeworks');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) {
            callback(parsed);
            return;
          }
        }
        callback(items);
      }
    },
    (err) => {
      handleFirestoreError(err, OperationType.GET, 'homeworks');
      try {
        const cached = localStorage.getItem('tuitionflow_cached_homeworks');
        if (cached) callback(JSON.parse(cached));
      } catch (e) {}
    }
  );
}

export function subscribeToSubmissions(callback: (submissions: Submission[]) => void) {
  try {
    const cached = localStorage.getItem('tuitionflow_cached_submissions');
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        callback(parsed);
      }
    }
  } catch (e) {}

  const collRef = collection(db, 'submissions');
  return onSnapshot(
    query(collRef),
    (snapshot) => {
      const items: Submission[] = [];
      snapshot.forEach((doc) => {
        items.push({ id: doc.id, ...(doc.data() as Omit<Submission, 'id'>) });
      });
      if (items.length > 0) {
        try {
          localStorage.setItem('tuitionflow_cached_submissions', JSON.stringify(items));
        } catch (e) {}
        callback(items);
      } else {
        const cached = localStorage.getItem('tuitionflow_cached_submissions');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) {
            callback(parsed);
            return;
          }
        }
        callback(items);
      }
    },
    (err) => {
      handleFirestoreError(err, OperationType.GET, 'submissions');
      try {
        const cached = localStorage.getItem('tuitionflow_cached_submissions');
        if (cached) callback(JSON.parse(cached));
      } catch (e) {}
    }
  );
}

// Helper to remove any undefined fields before sending to Firestore
function sanitizeData<T extends Record<string, any>>(data: T): Record<string, any> {
  const clean: Record<string, any> = {};
  for (const [key, val] of Object.entries(data)) {
    if (val !== undefined) {
      clean[key] = val;
    }
  }
  return clean;
}

// 6. Mutators
export async function saveStudent(student: Student) {
  try {
    const docRef = doc(db, 'students', student.id);
    const cleaned = sanitizeData(student);
    await setDoc(docRef, cleaned, { merge: true });
    try {
      const stored = localStorage.getItem('tuitionflow_cached_students');
      const list: Student[] = stored ? JSON.parse(stored) : [];
      const updated = list.some((s) => s.id === student.id)
        ? list.map((s) => (s.id === student.id ? student : s))
        : [student, ...list];
      localStorage.setItem('tuitionflow_cached_students', JSON.stringify(updated));
    } catch (e) {}
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `students/${student.id}`);
    throw err;
  }
}

export async function deleteStudent(studentId: string) {
  try {
    await deleteDoc(doc(db, 'students', studentId));
    try {
      const stored = localStorage.getItem('tuitionflow_cached_students');
      if (stored) {
        const list: Student[] = JSON.parse(stored);
        localStorage.setItem(
          'tuitionflow_cached_students',
          JSON.stringify(list.filter((s) => s.id !== studentId))
        );
      }
    } catch (e) {}
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `students/${studentId}`);
    throw err;
  }
}

export async function saveHomework(homework: Homework) {
  try {
    const docRef = doc(db, 'homeworks', homework.id);
    const cleaned = sanitizeData(homework);
    await setDoc(docRef, cleaned, { merge: true });
    try {
      const stored = localStorage.getItem('tuitionflow_cached_homeworks');
      const list: Homework[] = stored ? JSON.parse(stored) : [];
      const updated = list.some((h) => h.id === homework.id)
        ? list.map((h) => (h.id === homework.id ? homework : h))
        : [homework, ...list];
      localStorage.setItem('tuitionflow_cached_homeworks', JSON.stringify(updated));
    } catch (e) {}
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `homeworks/${homework.id}`);
    throw err;
  }
}

export async function deleteHomework(homeworkId: string) {
  try {
    await deleteDoc(doc(db, 'homeworks', homeworkId));
    try {
      const stored = localStorage.getItem('tuitionflow_cached_homeworks');
      if (stored) {
        const list: Homework[] = JSON.parse(stored);
        localStorage.setItem(
          'tuitionflow_cached_homeworks',
          JSON.stringify(list.filter((h) => h.id !== homeworkId))
        );
      }
    } catch (e) {}
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `homeworks/${homeworkId}`);
    throw err;
  }
}

export async function saveSubmission(submission: Submission) {
  try {
    const docRef = doc(db, 'submissions', submission.id);
    const cleaned = sanitizeData(submission);
    await setDoc(docRef, cleaned, { merge: true });
    try {
      const stored = localStorage.getItem('tuitionflow_cached_submissions');
      const list: Submission[] = stored ? JSON.parse(stored) : [];
      const updated = list.some((s) => s.id === submission.id)
        ? list.map((s) => (s.id === submission.id ? submission : s))
        : [submission, ...list];
      localStorage.setItem('tuitionflow_cached_submissions', JSON.stringify(updated));
    } catch (e) {}
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `submissions/${submission.id}`);
    throw err;
  }
}

// Seed helper to populate initial demo data if database is empty
export async function seedInitialDemoDataIfEmpty(
  currentStudents: Student[],
  currentHomeworks: Homework[],
  currentSubmissions: Submission[]
) {
  if (currentStudents.length === 0) {
    for (const student of INITIAL_DEMO_STUDENTS) {
      await saveStudent(student).catch(console.error);
    }
  }
  if (currentHomeworks.length === 0) {
    for (const hw of INITIAL_DEMO_HOMEWORKS) {
      await saveHomework(hw).catch(console.error);
    }
  }
  if (currentSubmissions.length === 0) {
    for (const sub of INITIAL_DEMO_SUBMISSIONS) {
      await saveSubmission(sub).catch(console.error);
    }
  }
}
