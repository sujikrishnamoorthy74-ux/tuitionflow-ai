import React, { useState, useEffect } from 'react';
import {
  Student,
  Homework,
  Submission,
  Language,
} from './types';
import { enTranslations, taTranslations } from './locales/translations';
import {
  testConnection,
  subscribeToStudents,
  subscribeToHomeworks,
  subscribeToSubmissions,
  saveStudent as dbSaveStudent,
  deleteStudent as dbDeleteStudent,
  saveHomework as dbSaveHomework,
  deleteHomework as dbDeleteHomework,
  saveSubmission as dbSaveSubmission,
  seedInitialDemoDataIfEmpty,
} from './lib/firebase';
import { Navbar } from './components/Navbar';
import { TeacherDashboard } from './components/TeacherDashboard';
import { StudentPortal } from './components/StudentPortal';
import { StudentModal } from './components/StudentModal';
import { CreateHomeworkModal } from './components/CreateHomeworkModal';
import { PrintableWorksheet } from './components/PrintableWorksheet';
import { SetupGuideModal } from './components/SetupGuideModal';
import { playGentleChime } from './utils/audioReminder';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const t = lang === 'ta' ? taTranslations : enTranslations;

  const [activeRole, setActiveRole] = useState<'teacher' | 'student'>('teacher');
  const [currentStudent, setCurrentStudent] = useState<Student | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Firestore real-time data
  const [students, setStudents] = useState<Student[]>([]);
  const [homeworks, setHomeworks] = useState<Homework[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [isDbLoaded, setIsDbLoaded] = useState(false);

  // Modals state
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const [isCreateHomeworkModalOpen, setIsCreateHomeworkModalOpen] = useState(false);
  const [editingHomework, setEditingHomework] = useState<Homework | null>(null);

  const [printingHomework, setPrintingHomework] = useState<Homework | null>(null);
  const [isSetupGuideOpen, setIsSetupGuideOpen] = useState(false);

  // Network online indicator
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Initialize Firestore listeners & test connection
  useEffect(() => {
    testConnection();

    const unsubStudents = subscribeToStudents((list) => {
      setStudents(list);
      setIsDbLoaded(true);
    });

    const unsubHomeworks = subscribeToHomeworks((list) => {
      setHomeworks(list);
    });

    const unsubSubmissions = subscribeToSubmissions((list) => {
      setSubmissions(list);
    });

    return () => {
      unsubStudents();
      unsubHomeworks();
      unsubSubmissions();
    };
  }, []);

  // Auto seed demo students and sample homework if empty
  useEffect(() => {
    if (isDbLoaded && students.length === 0 && homeworks.length === 0) {
      seedInitialDemoDataIfEmpty(students, homeworks, submissions);
    }
  }, [isDbLoaded, students.length, homeworks.length, submissions]);

  // Restore student session if previously logged in or via URL param
  useEffect(() => {
    if (students.length > 0) {
      const urlParams = new URLSearchParams(window.location.search);
      const studentParam = urlParams.get('student');
      if (studentParam) {
        const found = students.find(
          (s) =>
            s.studentCode.toUpperCase() === studentParam.toUpperCase() ||
            s.id === studentParam
        );
        if (found) {
          setCurrentStudent(found);
          setActiveRole('student');
          try {
            localStorage.setItem('tuitionflow_saved_student_id', found.id);
          } catch (e) {}
          return;
        }
      }

      // If not set, restore previously saved student from localStorage
      if (!currentStudent) {
        try {
          const savedId = localStorage.getItem('tuitionflow_saved_student_id');
          if (savedId) {
            const found = students.find((s) => s.id === savedId);
            if (found) {
              setCurrentStudent(found);
            }
          }
        } catch (e) {}
      }
    }
  }, [students, currentStudent]);

  // Student Mutators with instant optimistic updates
  const handleSaveStudent = async (student: Student) => {
    // 1. Optimistic update
    setStudents((prev) => {
      const exists = prev.some((s) => s.id === student.id);
      const updated = exists ? prev.map((s) => (s.id === student.id ? student : s)) : [student, ...prev];
      try {
        localStorage.setItem('tuitionflow_cached_students', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    // 2. Update studentName in any existing submissions if name was changed
    setSubmissions((prev) =>
      prev.map((sub) => (sub.studentId === student.id ? { ...sub, studentName: student.name } : sub))
    );

    // 3. Update currentStudent if this student is active
    if (currentStudent && currentStudent.id === student.id) {
      setCurrentStudent(student);
    }

    try {
      await dbSaveStudent(student);
    } catch (err) {
      console.warn('Student saved locally, syncing in background:', err);
    }
    if (soundEnabled) playGentleChime('alert');
  };

  const handleDeleteStudent = async (studentId: string) => {
    if (window.confirm(t.confirmDelete)) {
      setStudents((prev) => {
        const updated = prev.filter((s) => s.id !== studentId);
        try {
          localStorage.setItem('tuitionflow_cached_students', JSON.stringify(updated));
        } catch (e) {}
        return updated;
      });
      if (currentStudent?.id === studentId) {
        setCurrentStudent(null);
        try {
          localStorage.removeItem('tuitionflow_saved_student_id');
        } catch (e) {}
      }
      try {
        await dbDeleteStudent(studentId);
      } catch (err) {
        console.warn('Delete synced in background:', err);
      }
    }
  };

  // Homework Mutators
  const handleSaveHomework = async (hw: Homework) => {
    setHomeworks((prev) => {
      const exists = prev.some((h) => h.id === hw.id);
      const updated = exists ? prev.map((h) => (h.id === hw.id ? hw : h)) : [hw, ...prev];
      try {
        localStorage.setItem('tuitionflow_cached_homeworks', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    try {
      await dbSaveHomework(hw);
    } catch (err) {
      console.warn('Homework saved locally, syncing in background:', err);
    }
    if (soundEnabled) playGentleChime('alert');
  };

  const handleDeleteHomework = async (homeworkId: string) => {
    if (window.confirm(t.confirmDelete)) {
      setHomeworks((prev) => {
        const updated = prev.filter((h) => h.id !== homeworkId);
        try {
          localStorage.setItem('tuitionflow_cached_homeworks', JSON.stringify(updated));
        } catch (e) {}
        return updated;
      });
      try {
        await dbDeleteHomework(homeworkId);
      } catch (err) {
        console.warn('Delete homework synced in background:', err);
      }
    }
  };

  // Submission Mutators
  const handleSaveSubmission = async (sub: Submission) => {
    setSubmissions((prev) => {
      const exists = prev.some((s) => s.id === sub.id);
      const updated = exists ? prev.map((s) => (s.id === sub.id ? sub : s)) : [sub, ...prev];
      try {
        localStorage.setItem('tuitionflow_cached_submissions', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    try {
      await dbSaveSubmission(sub);
    } catch (err) {
      console.warn('Submission saved locally, syncing in background:', err);
    }
  };

  const handleUpdateSubmissionStatus = async (
    submissionId: string,
    status: 'approved' | 'needs_correction',
    feedback: string
  ) => {
    const existing = submissions.find((s) => s.id === submissionId);
    if (existing) {
      const updated: Submission = {
        ...existing,
        status,
        teacherFeedback: feedback.trim() || undefined,
        updatedAt: new Date().toISOString(),
      };
      await dbSaveSubmission(updated);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/60 font-sans text-slate-800 antialiased flex flex-col selection:bg-blue-500 selection:text-white">
      {/* Offline Mode Alert */}
      {!isOnline && (
        <div className="bg-amber-500 text-white text-xs font-bold py-1.5 px-4 text-center sticky top-0 z-50 shadow-sm flex items-center justify-center gap-2">
          <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
          <span>Offline Mode — Cached data is being used. Changes will sync when reconnected.</span>
        </div>
      )}

      {/* Navigation Header */}
      <Navbar
        lang={lang}
        onToggleLang={() => setLang(lang === 'en' ? 'ta' : 'en')}
        activeRole={activeRole}
        onSwitchRole={(role) => setActiveRole(role)}
        currentStudent={currentStudent}
        onStudentLogout={() => {
          setCurrentStudent(null);
          try {
            localStorage.removeItem('tuitionflow_saved_student_id');
          } catch (e) {}
          if (typeof window !== 'undefined' && window.history.replaceState) {
            window.history.replaceState({}, document.title, window.location.pathname);
          }
        }}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
        onOpenSetupGuide={() => setIsSetupGuideOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        {activeRole === 'teacher' ? (
          <TeacherDashboard
            students={students}
            homeworks={homeworks}
            submissions={submissions}
            lang={lang}
            t={t}
            onAddStudent={() => {
              setEditingStudent(null);
              setIsStudentModalOpen(true);
            }}
            onEditStudent={(s) => {
              setEditingStudent(s);
              setIsStudentModalOpen(true);
            }}
            onDeleteStudent={handleDeleteStudent}
            onCreateHomework={() => {
              setEditingHomework(null);
              setIsCreateHomeworkModalOpen(true);
            }}
            onEditHomework={(hw) => {
              setEditingHomework(hw);
              setIsCreateHomeworkModalOpen(true);
            }}
            onDeleteHomework={handleDeleteHomework}
            onPrintHomework={(hw) => setPrintingHomework(hw)}
            onOpenAsStudent={(s) => {
              setCurrentStudent(s);
              try {
                localStorage.setItem('tuitionflow_saved_student_id', s.id);
              } catch (e) {}
              setActiveRole('student');
            }}
            onUpdateSubmissionStatus={handleUpdateSubmissionStatus}
          />
        ) : (
          <StudentPortal
            currentStudent={currentStudent}
            students={students}
            homeworks={homeworks}
            submissions={submissions}
            lang={lang}
            t={t}
            soundEnabled={soundEnabled}
            onToggleSound={() => setSoundEnabled(!soundEnabled)}
            onSelectStudent={(s) => {
              setCurrentStudent(s);
              try {
                localStorage.setItem('tuitionflow_saved_student_id', s.id);
              } catch (e) {}
            }}
            onLogoutStudent={() => {
              setCurrentStudent(null);
              try {
                localStorage.removeItem('tuitionflow_saved_student_id');
              } catch (e) {}
              if (typeof window !== 'undefined' && window.history.replaceState) {
                window.history.replaceState({}, document.title, window.location.pathname);
              }
            }}
            onSaveSubmission={handleSaveSubmission}
            onPrintHomework={(hw) => setPrintingHomework(hw)}
          />
        )}
      </main>

      {/* Modals */}
      <StudentModal
        isOpen={isStudentModalOpen}
        onClose={() => setIsStudentModalOpen(false)}
        onSave={handleSaveStudent}
        editingStudent={editingStudent}
        existingStudentsCount={students.length}
        lang={lang}
        t={t}
      />

      <CreateHomeworkModal
        isOpen={isCreateHomeworkModalOpen}
        onClose={() => setIsCreateHomeworkModalOpen(false)}
        onSave={handleSaveHomework}
        editingHomework={editingHomework}
        students={students}
        lang={lang}
        t={t}
      />

      {printingHomework && (
        <PrintableWorksheet
          homework={printingHomework}
          lang={lang}
          onClose={() => setPrintingHomework(null)}
        />
      )}

      <SetupGuideModal
        isOpen={isSetupGuideOpen}
        onClose={() => setIsSetupGuideOpen(false)}
        lang={lang}
        t={t}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200/80 bg-white/70 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span className="font-semibold text-slate-700">TuitionFlow AI</span>
            <span>—</span>
            <span>{lang === 'ta' ? 'ஸ்மார்ட் வீட்டுப்பாடம் போர்டல்' : 'Smart Tuition Homework Portal'}</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <button
              onClick={() => setIsSetupGuideOpen(true)}
              className="text-blue-600 hover:underline font-semibold"
            >
              {t.setupGuide}
            </button>
            <span className="text-slate-300">•</span>
            <span>Tamil & English Bilingual</span>
            <span className="text-slate-300">•</span>
            <span className="text-emerald-700 font-semibold">Cloud Firestore Live</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
