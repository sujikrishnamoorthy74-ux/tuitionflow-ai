export type Subject = 'Tamil' | 'English' | 'Maths' | 'Science' | 'Social Science';

export type SubmissionStatus = 'pending' | 'submitted' | 'approved' | 'needs_correction';

export interface Student {
  id: string;
  name: string;
  studentCode: string; // e.g., 'STU-101'
  grade: string;       // e.g., 'Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10'
  parentPhone?: string;
  createdAt: string;
}

export interface Homework {
  id: string;
  title: string;
  subject: Subject;
  instructions: string;
  dueDate: string; // YYYY-MM-DD
  assignedStudentIds: string[]; // List of Student IDs
  attachmentUrl?: string; // Image or document data URL
  createdAt: string;
  createdBy?: string;
}

export interface Submission {
  id: string;
  homeworkId: string;
  studentId: string;
  studentName: string;
  answer: string;
  draftAnswer?: string;
  attachmentUrl?: string; // Student's homework photo/scan
  status: SubmissionStatus;
  teacherFeedback?: string;
  submittedAt?: string;
  updatedAt: string;
}

export type Language = 'en' | 'ta';

export interface Translations {
  appName: string;
  appSubtitle: string;
  teacherPortal: string;
  studentPortal: string;
  students: string;
  createHomework: string;
  assignedHomework: string;
  submissions: string;
  totalStudents: string;
  activeAssignments: string;
  pendingReviews: string;
  approvedCount: string;
  searchStudent: string;
  allGrades: string;
  addStudent: string;
  editStudent: string;
  deleteStudent: string;
  studentName: string;
  gradeClass: string;
  parentPhone: string;
  studentCode: string;
  saveStudent: string;
  cancel: string;
  confirmDelete: string;
  copyStudentLink: string;
  linkCopied: string;
  homeworkTitle: string;
  subject: string;
  instructions: string;
  dueDate: string;
  assignToStudents: string;
  selectAll: string;
  deselectAll: string;
  optionalAttachment: string;
  uploadWorksheetImage: string;
  assignHomeworkBtn: string;
  editHomework: string;
  deleteHomework: string;
  startHomework: string;
  typeYourAnswer: string;
  saveProgress: string;
  submitHomework: string;
  resubmitHomework: string;
  uploadPhoto: string;
  submissionSuccess: string;
  approvedStatus: string;
  pendingStatus: string;
  submittedStatus: string;
  needsCorrectionStatus: string;
  teacherFeedbackLabel: string;
  approveBtn: string;
  requestCorrectionBtn: string;
  feedbackPlaceholder: string;
  enterStudentCode: string;
  studentLoginPrompt: string;
  loginAsStudent: string;
  logout: string;
  switchRole: string;
  noHomeworkFound: string;
  reminderNotice: string;
  reminderSoundOn: string;
  reminderSoundOff: string;
  printWorksheet: string;
  overdue: string;
  dueSoon: string;
  completedTasks: string;
  progressLabel: string;
  databaseConnected: string;
  backendConfigNotice: string;
  setupGuide: string;
}
